# Fiabilité des annonces

Un service qui dit si une annonce d'occasion est **fiable, à vérifier, risquée ou à éviter**, avec les raisons.

Il ne récupère aucune annonce lui-même : on lui décrit une annonce, il rend un verdict. Il s'utilise de trois façons :

1. **Votre bot d'alertes existant l'appelle avant de publier** (API locale, n'importe quel langage).
2. **Import direct** dans un bot Python : `from fiabilite import evaluer`.
3. **Commande Discord `/verifier`** pour vérifier une annonce à la main.

## Démarrer (Windows)

1. Mettez le token du bot Discord dans un fichier **token.txt** sur le bureau (ou dans ce dossier).
   Sans token, seule l'API tourne, ce qui suffit pour le branchement avec votre bot existant.
2. Double-cliquez sur **lancer.bat**. Laissez la fenêtre ouverte.
3. L'API répond sur `http://127.0.0.1:8787`, et `/verifier` apparaît sur tous les serveurs où le bot est invité.

## Brancher votre bot d'alertes existant

Juste avant de publier une alerte, votre bot envoie l'annonce à l'API et lit la réponse :

- `publier: false` : on n'envoie pas l'alerte (arnaque probable, objet pas en main, paiement hors Vinted…).
- `publier: true` : on l'envoie, en ajoutant le verdict et les raisons dans la carte.

Le code prêt à copier est dans **exemples/branchement_python.py** (discord.py) et **exemples/branchement_javascript.js** (discord.js). Il suffit d'adapter les noms de champs à ceux de votre bot.

Les deux bots doivent tourner sur le **même ordinateur** (l'API n'écoute que `127.0.0.1`). Pour l'ouvrir à un autre ordinateur, mettez `"hote": "0.0.0.0"` dans config.json **et** créez un fichier **cle-api.txt** contenant un mot de passe long : chaque appel devra alors envoyer l'en-tête `X-Cle-Api`.

## Format d'entrée (`POST /evaluer`)

Tout est facultatif sauf `titre` et `prix_total` (ou `prix`). Plus vous en envoyez, plus l'analyse est sûre : la réponse liste les `infos_manquantes`.

```json
{
  "id": "123456",
  "titre": "Manette PS5 édition collector",
  "description": "Texte complet de l'annonce",
  "prix": 180,
  "prix_total": 189.70,
  "url": "https://www.vinted.fr/items/123456",
  "categorie": "playstation",
  "marque": "Sony",
  "etat": "Neuf avec étiquette",
  "photos": ["https://.../1.jpg"],
  "nb_photos": 3,
  "vendeur": {"pseudo": "x", "nb_avis": 12, "note": 4.8, "anciennete_jours": 300, "nb_articles_meme_marque": 1},
  "marche": {"mediane_ventes": 330, "nb_ventes": 3, "mediane_annonces": 500, "nb_annonces": 36,
             "prix_neuf": 84.99, "date_sortie": "2026-11-19"},
  "revente": {"frais": 11, "taux_cotisations": 0.123}
}
```

`marche.mediane_ventes` est le prix **réellement payé** (ventes), pas le prix demandé. C'est la référence utilisée pour juger le prix.

## Format de sortie

```json
{
  "id": "123456", "score": 0, "verdict": "a_eviter", "libelle": "À éviter",
  "bloquee": true, "publier": false,
  "raisons": [{"code": "pas_en_main", "points": -100, "texte": "Le vendeur n'a pas l'objet en main (« apres sa reception »).", "bloquante": true}],
  "ecart_prix_pct": 43,
  "marge": {"prix_revente": 330, "frais_revente": 11, "brute": 129.3, "cotisations": 40.59, "nette": 88.71},
  "infos_manquantes": [],
  "categorie": "playstation",
  "checklist": ["..."],
  "message_vendeur": "Bonjour, votre annonce ...",
  "avertissement": "Analyse automatique : estimation, pas une garantie."
}
```

Verdicts : `fiable` (75 et plus), `a_verifier` (50 à 74), `risque_eleve` (moins de 50), `a_eviter` (signal bloquant). `POST /evaluer-lot` accepte une liste de 100 annonces au maximum. `GET /sante` vérifie que le service tourne.

## Ce qui est vérifié

| Signal | Effet |
|---|---|
| Objet pas en main (« après sa réception », précommande…), produit pas encore sorti | Bloquant |
| Paiement hors Vinted (PayPal, virement, Lydia, « hors Vinted »…) | Bloquant |
| Photo déjà vue ailleurs (si un vérificateur d'image est branché) | Bloquant |
| Mots de contrefaçon (`1:1`, `UA`, réplique…) | −50 |
| Contact hors Vinted (WhatsApp, téléphone, e-mail, lien externe) | −30 |
| Prix plus de 60 % / 40 à 60 % sous les ventes (objet d'au moins 50 €) | −35 / −25 |
| Vendeur sans avis, compte de moins de 30 jours, gros stock d'une même marque | −20, −15, −15 |
| Compte récent **et** prix très bas | −10 en plus |
| Photos « internet » / non contractuelles | −15 |
| Référence de prix basée sur moins de 5 ventes, ou spéculative (plus de 2x le prix neuf) | −15 |
| Une seule photo, pression à acheter vite, description très courte | −10, −5, −5 |

Une information **non fournie** n'est jamais comptée comme mauvaise : un nombre de photos inconnu n'est pas « une seule photo ». Le profil vendeur absent ou une référence de prix absente coûtent quelques points, pour inciter à les fournir. Les seuils sont dans `Reglages` (fiabilite/scoring.py) et les mots-clés dans fiabilite/keywords.py.

## Tests

```bash
python -m pytest
```

## Limites

- C'est une aide à la décision, **pas une garantie** : une annonce bien écrite peut rester une arnaque. Gardez la protection acheteur Vinted et filmez le déballage.
- La recherche d'image inversée n'est pas incluse : l'interface `VerificateurImage` est prête si vous choisissez un service.
- Les boutons de `/verifier` expirent au bout d'une heure ou au redémarrage du bot.
- Le taux de cotisations (12,3 %) est un ordre de grandeur, à confirmer sur urssaf.fr.
