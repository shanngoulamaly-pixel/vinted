"""Lance l'API de fiabilité, et le bot Discord si un token est disponible.

    python main.py                  (config.json du dossier)
    python main.py --sans-discord   (API seule)
"""

from __future__ import annotations

import argparse
import asyncio
import logging

from fiabilite.config import charger_config, cle_api, token_discord
from fiabilite.serveur import creer_app, demarrer


async def lancer(sans_discord: bool, chemin_config: str) -> None:
    cfg = charger_config(chemin_config)
    cle = cle_api()
    runner = await demarrer(creer_app(cfg.options, cle), cfg.hote, cfg.port)
    if cle:
        logging.info("Clé API active : les appels doivent envoyer l'en-tête X-Cle-Api.")
    try:
        token = None if sans_discord else token_discord()
        if token:
            from fiabilite.bot import BotFiabilite

            bot = BotFiabilite(cfg.options)
            async with bot:
                await bot.start(token)
        else:
            if not sans_discord:
                logging.warning("Pas de token Discord (token.txt) : seule l'API tourne.")
            await asyncio.Event().wait()
    finally:
        await runner.cleanup()


def main() -> None:
    parser = argparse.ArgumentParser(description="Bot de fiabilité des annonces")
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--sans-discord", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        asyncio.run(lancer(args.sans_discord, args.config))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
