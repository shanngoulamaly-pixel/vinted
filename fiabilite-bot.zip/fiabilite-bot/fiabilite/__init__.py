"""Évaluation de la fiabilité d'annonces d'occasion (Vinted et autres).

    from fiabilite import evaluer
    resultat = evaluer({"titre": "...", "prix_total": 45.0, "description": "..."})
    if resultat["publier"]:
        ...
"""

from .api import ErreurEntree, Options, evaluer

__all__ = ["evaluer", "Options", "ErreurEntree"]
