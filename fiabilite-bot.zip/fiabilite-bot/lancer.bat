@echo off
setlocal
cd /d "%~dp0"
title Fiabilite des annonces

set "PY="
py --version >nul 2>nul && set "PY=py"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo  Python n'est pas installe. Installe-le depuis https://www.python.org/downloads/
  echo  en cochant "Add python.exe to PATH", puis relance ce fichier.
  pause
  exit /b 1
)

echo Installation des dependances...
%PY% -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 (
  echo  Echec de l'installation des dependances. Envoie une capture de cette fenetre.
  pause
  exit /b 1
)

echo Demarrage. Laisse cette fenetre ouverte ; ferme-la pour tout arreter.
%PY% main.py --config config.json
echo.
echo  Le bot s'est arrete.
pause
