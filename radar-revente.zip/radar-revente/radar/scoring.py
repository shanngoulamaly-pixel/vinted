"""Score de confiance d'une annonce (0 à 100) et raisons détaillées.

Principe : on part de 100 et on retire des points pour chaque signal de risque.
Certains signaux sont BLOQUANTS : l'alerte n'est pas envoyée, quel que soit le score.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Optional, Protocol

from .keywords import (
    find_counterfeit_strong,
    find_not_in_hand,
    find_suspicious_mild,
)
from .models import Listing, MarketStats


@dataclass(frozen=True)
class Reason:
    code: str
    delta: int  # négatif = pénalité
    text: str
    blocking: bool = False


@dataclass(frozen=True)
class ScoreResult:
    score: int
    blocked: bool
    reasons: tuple[Reason, ...]

    @property
    def label(self) -> str:
        if self.blocked:
            return "Bloquée"
        if self.score >= 75:
            return "Fiable"
        if self.score >= 50:
            return "À vérifier"
        return "Risque élevé"


@dataclass(frozen=True)
class ImageCheckResult:
    reused: Optional[bool]  # True : photo trouvée ailleurs ; None : non vérifié


class ImageChecker(Protocol):
    """Branchez ici une recherche d'image inversée (à vous de choisir le service)."""

    def check(self, photo_urls: tuple[str, ...]) -> ImageCheckResult: ...


@dataclass(frozen=True)
class ScoringConfig:
    # Écart de prix par rapport aux VENTES observées (pas aux annonces)
    gap_suspicious: float = 0.40  # au-delà : trop beau pour être vrai
    gap_extreme: float = 0.60
    min_sold_ok: int = 10  # en dessous, la médiane est peu fiable
    min_sold_weak: int = 5
    speculative_ratio: float = 2.0  # revente observée > 2x le prix officiel
    # Un gros écart de prix n'est un signal d'arnaque que sur des articles qui valent la peine d'être
    # contrefaits : sous cette valeur, un vendeur qui ne connaît pas le prix est l'explication normale.
    gap_min_value: float = 50.0


def price_gap(listing: Listing, market: MarketStats) -> Optional[float]:
    """Écart du prix payé par rapport à la médiane des ventes : 0,43 = 43 % moins cher."""
    if not market.median_sold or market.median_sold <= 0 or listing.buyer_total <= 0:
        return None
    return 1 - listing.buyer_total / market.median_sold


def score_listing(
    listing: Listing,
    market: MarketStats,
    today: Optional[date] = None,
    image_checker: Optional[ImageChecker] = None,
    config: ScoringConfig = ScoringConfig(),
) -> ScoreResult:
    today = today or date.today()
    reasons: list[Reason] = []
    text = f"{listing.title}\n{listing.description}"

    # 1. L'objet n'existe pas encore ou n'est pas chez le vendeur : on bloque.
    if market.release_date and today < market.release_date:
        reasons.append(
            Reason(
                "not_released",
                -100,
                f"Produit pas encore sorti (sortie le {market.release_date.strftime('%d/%m/%Y')}).",
                blocking=True,
            )
        )
    hits = find_not_in_hand(text)
    if hits:
        reasons.append(
            Reason(
                "not_in_hand",
                -100,
                f"Le vendeur n'a pas l'objet en main (« {hits[0]} »).",
                blocking=True,
            )
        )

    # 2. Contrefaçon
    strong = find_counterfeit_strong(text)
    if strong:
        reasons.append(
            Reason("counterfeit", -50, f"Mot-clé de contrefaçon : « {strong[0]} ».")
        )
    mild = find_suspicious_mild(text)
    if mild:
        reasons.append(Reason("mild_keyword", -10, f"Mot-clé à vérifier : « {mild[0]} »."))

    # 3. Prix par rapport aux ventes réelles
    gap = price_gap(listing, market)
    if gap is None:
        reasons.append(Reason("no_reference", -15, "Pas de prix de vente de référence."))
    else:
        pct = round(gap * 100)
        if market.median_sold < config.gap_min_value:
            pass  # article à faible valeur : un grand écart de prix n'est pas un signal de risque
        elif gap > config.gap_extreme:
            reasons.append(Reason("gap_extreme", -35, f"Prix {pct} % sous les ventes : très suspect."))
        elif gap > config.gap_suspicious:
            reasons.append(
                Reason("gap_suspicious", -25, f"Prix {pct} % sous les ventes : possible arnaque ou contrefaçon.")
            )
        elif gap > 0.25:
            reasons.append(Reason("gap_notable", -5, f"Prix {pct} % sous les ventes."))

    # 4. Fiabilité de la référence
    if market.median_sold:
        if market.n_sold < config.min_sold_weak:
            reasons.append(Reason("few_sales", -15, f"Médiane basée sur seulement {market.n_sold} ventes."))
        elif market.n_sold < config.min_sold_ok:
            reasons.append(Reason("some_sales", -5, f"Médiane basée sur {market.n_sold} ventes."))

    # 5. Référence spéculative : revente observée très au-dessus du prix officiel
    if (
        market.official_price
        and market.median_sold
        and market.median_sold > config.speculative_ratio * market.official_price
    ):
        reasons.append(
            Reason(
                "speculative",
                -15,
                f"Revente observée ({market.median_sold:.0f} €) plus de {config.speculative_ratio:.0f}x "
                f"le prix officiel ({market.official_price:.0f} €) : référence spéculative.",
            )
        )

    # 6. Vendeur
    s = listing.seller
    if s is None:
        reasons.append(Reason("seller_unknown", -10, "Profil du vendeur inconnu."))
    else:
        if s.rating_count == 0:
            reasons.append(Reason("seller_no_reviews", -20, "Vendeur sans aucun avis."))
        elif s.rating_count < 5:
            reasons.append(Reason("seller_few_reviews", -10, f"Vendeur avec seulement {s.rating_count} avis."))
        elif s.rating_avg is not None and s.rating_avg < 4.5:
            reasons.append(Reason("seller_low_rating", -10, f"Note du vendeur : {s.rating_avg:.1f}/5."))
        if s.account_age_days is not None and s.account_age_days < 30:
            reasons.append(Reason("seller_new", -15, "Compte créé il y a moins de 30 jours."))
        if s.same_brand_listings > 10:
            reasons.append(
                Reason("seller_stock", -15, f"Le vendeur propose {s.same_brand_listings} articles de la même marque.")
            )

    # 7. Photos
    if len(listing.photos) <= 1:
        reasons.append(Reason("few_photos", -10, "Une seule photo (ou aucune)."))
    if image_checker is not None and listing.photos:
        result = image_checker.check(listing.photos)
        if result.reused:
            reasons.append(
                Reason("photo_reused", -100, "Photo déjà présente ailleurs sur internet.", blocking=True)
            )

    # 8. Description
    if len(listing.description.strip()) < 20:
        reasons.append(Reason("short_description", -5, "Description très courte."))

    blocked = any(r.blocking for r in reasons)
    score = 0 if blocked else max(0, min(100, 100 + sum(r.delta for r in reasons)))
    # On trie : bloquantes d'abord, puis les plus fortes pénalités.
    ordered = tuple(sorted(reasons, key=lambda r: (not r.blocking, r.delta)))
    return ScoreResult(score=score, blocked=blocked, reasons=ordered)
