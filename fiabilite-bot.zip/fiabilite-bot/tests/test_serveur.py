import asyncio

from aiohttp.test_utils import TestClient, TestServer

from fiabilite.serveur import MAX_LOT, creer_app

ANNONCE = {
    "titre": "Console portable", "prix_total": 65.4,
    "description": "Console testée et fonctionnelle, chargeur inclus.",
    "marche": {"mediane_ventes": 105, "nb_ventes": 22},
}


def appel(cle=None, fn=None):
    async def run():
        async with TestClient(TestServer(creer_app(cle_api=cle))) as client:
            await fn(client)

    asyncio.run(run())


def test_sante_et_evaluation():
    async def fn(c):
        r = await c.get("/sante")
        assert r.status == 200 and (await r.json())["ok"]
        r = await c.post("/evaluer", json=ANNONCE)
        assert r.status == 200
        body = await r.json()
        assert body["verdict"] in {"fiable", "a_verifier"} and "raisons" in body

    appel(fn=fn)


def test_erreurs_400():
    async def fn(c):
        r = await c.post("/evaluer", data="pas du json", headers={"Content-Type": "application/json"})
        assert r.status == 400 and "JSON" in (await r.json())["erreur"]
        r = await c.post("/evaluer", json={"prix_total": 3})
        assert r.status == 400 and "titre" in (await r.json())["erreur"]

    appel(fn=fn)


def test_lot_avec_une_annonce_invalide():
    async def fn(c):
        r = await c.post("/evaluer-lot", json=[ANNONCE, {"titre": "sans prix"}])
        body = await r.json()
        assert r.status == 200 and len(body) == 2
        assert "score" in body[0] and body[1]["index"] == 1 and "erreur" in body[1]
        r = await c.post("/evaluer-lot", json=[ANNONCE] * (MAX_LOT + 1))
        assert r.status == 400

    appel(fn=fn)


def test_cle_api():
    async def fn(c):
        assert (await c.get("/sante")).status == 200  # la santé reste publique
        assert (await c.post("/evaluer", json=ANNONCE)).status == 401
        assert (await c.post("/evaluer", json=ANNONCE, headers={"X-Cle-Api": "faux"})).status == 401
        assert (await c.post("/evaluer", json=ANNONCE, headers={"X-Cle-Api": "secret"})).status == 200

    appel(cle="secret", fn=fn)
