"""Structures de données partagées. Aucune dépendance à Discord ni à Vinted."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional


@dataclass(frozen=True)
class Seller:
    username: str
    rating_count: int = 0
    rating_avg: Optional[float] = None  # note moyenne sur 5
    account_age_days: Optional[int] = None
    same_brand_listings: int = 0  # nombre d'annonces de la même marque chez ce vendeur


@dataclass(frozen=True)
class Listing:
    id: str
    title: str
    description: str
    price: float  # prix affiché de l'article
    buyer_total: float  # ce que l'acheteur paie réellement, frais de protection inclus
    url: str
    category: str  # ex. "playstation", "vetements"
    brand: Optional[str] = None
    condition: Optional[str] = None
    photos: tuple[str, ...] = ()
    favourites: int = 0
    seller: Optional[Seller] = None


@dataclass(frozen=True)
class MarketStats:
    """Ce que l'on sait du marché pour cet article. Tout est optionnel."""

    median_sold: Optional[float] = None  # médiane des PRIX DE VENTE observés
    n_sold: int = 0  # nombre de ventes observées derrière cette médiane
    median_asking: Optional[float] = None  # médiane des prix DEMANDÉS (annonces actives)
    n_asking: int = 0
    official_price: Optional[float] = None  # prix neuf officiel, s'il existe
    official_url: Optional[str] = None
    release_date: Optional[date] = None  # date de sortie, pour les produits pas encore sortis


@dataclass(frozen=True)
class Candidate:
    """Une annonce et ce que l'on sait de son marché : l'unité de travail du bot."""

    listing: Listing
    market: MarketStats
