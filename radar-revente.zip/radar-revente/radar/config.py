"""Chargement de la configuration. Le token Discord vient de l'environnement, jamais d'un fichier."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class BotConfig:
    guild_id: Optional[int] = None
    min_score_to_post: int = 60
    cotisation_rate: float = 0.123  # micro-entreprise, vente de marchandises (à confirmer sur urssaf.fr)
    micro_entreprise: bool = True
    default_resale_costs: float = 5.0  # frais de revente estimés (port, emballage)
    resale_costs: dict[str, float] = field(default_factory=dict)  # par catégorie
    channels: dict[str, int] = field(default_factory=dict)  # "categorie" ou "categorie/marque" -> id salon
    roles: dict[str, int] = field(default_factory=dict)  # idem -> id rôle
    reports_path: str = "reports.jsonl"
    seen_path: str = "seen.json"
    poll_seconds: int = 60

    def costs_for(self, category: str) -> float:
        return self.resale_costs.get(category, self.default_resale_costs)


def load_config(path: str | Path) -> BotConfig:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return BotConfig(
        guild_id=raw.get("guild_id"),
        min_score_to_post=raw.get("min_score_to_post", 60),
        cotisation_rate=raw.get("cotisation_rate", 0.123),
        micro_entreprise=raw.get("micro_entreprise", True),
        default_resale_costs=raw.get("default_resale_costs", 5.0),
        resale_costs=raw.get("resale_costs", {}),
        channels=raw.get("channels", {}),
        roles=raw.get("roles", {}),
        reports_path=raw.get("reports_path", "reports.jsonl"),
        seen_path=raw.get("seen_path", "seen.json"),
        poll_seconds=raw.get("poll_seconds", 60),
    )


def discord_token() -> str:
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        raise SystemExit("Variable d'environnement DISCORD_TOKEN manquante.")
    return token
