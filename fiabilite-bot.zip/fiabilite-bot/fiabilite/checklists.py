"""Checklists de vérification par catégorie et modèle de message au vendeur."""

from __future__ import annotations

import re
import unicodedata

from .models import Annonce

COMMON = [
    "Paie uniquement via la protection acheteur Vinted, jamais en dehors.",
    "Filme le déballage : c'est ta preuve en cas de litige.",
    "Signale toute contrefaçon dans le délai de réclamation, avant de valider la réception.",
]

_FUNCTIONING = (
    "Demande une photo ou une vidéo de l'objet en fonctionnement "
    "(console allumée, manette connectée, écran qui s'affiche)."
)

BY_CATEGORY: dict[str, list[str]] = {
    "playstation": [_FUNCTIONING, "Vérifie les accessoires fournis et le numéro de série.", "Photo du dessous / de l'arrière de l'appareil."],
    "nintendo-switch": [_FUNCTIONING, "Vérifie que la console n'est pas verrouillée ou liée à un compte.", "Joy-Con : demande si la dérive du stick a été testée."],
    "retro-3ds-gameboy": [_FUNCTIONING, "Écran sans rayures profondes, pas de coque remplacée sans le dire.", "Pour les jeux : photo de la cartouche, vérifie les vis et l'étiquette."],
    "objets-high-tech": [_FUNCTIONING, "Demande le numéro de série et vérifie-le sur le site du fabricant.", "Vérifie que l'appareil n'est pas verrouillé par un compte."],
    "vetements": ["Photo des étiquettes (composition, taille, code article).", "Qualité des coutures et police des lettres comparées à un article authentique.", "Défauts, boulochage, taches : demande des photos de près."],
    "jeans": ["Photo de l'étiquette interne et de l'étiquette de composition.", "Boutons et rivets gravés, coutures régulières.", "Défauts et usure : demande des photos de près."],
    "chaussures": ["Code produit sous la languette : compare-le avec le site officiel.", "Boîte et étiquette de la boîte, si elles sont fournies.", "Semelle, coutures et odeur : une odeur de colle forte est suspecte."],
    "sacs": ["Numéro de série ou datecode à l'intérieur, comparé aux références de la marque.", "Qualité du cuir, coutures et quincaillerie (gravures nettes).", "Au-dessus de 100 € : un legit check payant est vite rentabilisé."],
    "luxe": ["Numéro de série ou datecode, certificat ou facture d'origine.", "Legit check par un service reconnu avant tout achat important.", "Évite les prix très en dessous du marché sans justification."],
    "beaute": ["Produit scellé, date de péremption visible.", "Photo du lot et du code de lot (batch).", "Méfie-toi des prix très bas sur les parfums de marque."],
    "lego": ["Numéro du set visible et correspondant à la description.", "Scellé d'origine intact, ou inventaire complet des pièces.", "Boîte, notices et figurines : demande des photos de tout."],
    "playmobil": ["Set complet ou liste des pièces manquantes.", "Photos de la boîte et de la notice.", "Pièces d'origine, pas de copies."],
    "cartes-pokemon": ["Photos recto et verso nettes, centrage et coins visibles.", "Compare avec une carte authentique (police, texture, hologramme).", "Carte gradée : vérifie le numéro de certification sur le site de l'organisme."],
    "cartes-gradees-et-non-gradees": ["Carte gradée : vérifie le numéro de certification (PSA, BGS, CGC) sur le site de l'organisme.", "Le numéro doit correspondre à la carte et au grade indiqués.", "Méfie-toi des faux boîtiers : étiquette, soudure et qualité du plastique."],
    "one-piece": ["Photos recto et verso nettes, coins et bords visibles.", "Compare avec une carte authentique.", "Carte rare : demande une photo à la lumière."],
    "vintage-deco": ["Photos de tous les angles et des marques / signatures.", "Dimensions et poids pour calculer le port avant d'acheter.", "Emballage soigné : les objets fragiles sont la première source de litiges."],
}

DEFAULT = ["Demande des photos supplémentaires et vérifie l'authenticité de l'objet."]


def slug(value: str | None) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(c for c in value if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "-", value).strip("-")


def checklist(categorie: str | None) -> list[str]:
    return BY_CATEGORY.get(slug(categorie), DEFAULT) + COMMON


def message_vendeur(annonce: Annonce) -> str:
    offre = max(1, round(annonce.prix_article * 0.85))
    return (
        f"Bonjour, votre annonce « {annonce.titre} » est-elle toujours disponible ? "
        "Pourriez-vous m'envoyer une photo prise aujourd'hui avec un papier daté posé à côté de l'article ? "
        f"Si tout est en ordre, seriez-vous d'accord pour {offre} € ? Merci !"
    )
