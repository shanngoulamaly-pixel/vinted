"""Décision d'envoi : score, marge, routage. Pur Python, facile à tester."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Optional

from .config import BotConfig
from .margin import MarginResult, compute_margin
from .models import Candidate
from .routing import Route, route
from .scoring import ImageChecker, ScoreResult, score_listing


@dataclass(frozen=True)
class Decision:
    candidate: Candidate
    score: ScoreResult
    margin: Optional[MarginResult]
    route: Route
    post: bool
    skip_reason: Optional[str] = None


def evaluate(
    candidate: Candidate,
    cfg: BotConfig,
    image_checker: Optional[ImageChecker] = None,
    today: Optional[date] = None,
) -> Decision:
    listing, market = candidate.listing, candidate.market
    score = score_listing(listing, market, today=today, image_checker=image_checker)

    margin = None
    if market.median_sold:
        margin = compute_margin(
            buy_total=listing.buyer_total,
            resale_price=market.median_sold,
            resale_costs=cfg.costs_for(listing.category),
            cotisation_rate=cfg.cotisation_rate,
            micro_entreprise=cfg.micro_entreprise,
        )

    r = route(listing, cfg.channels, cfg.roles)

    skip = None
    if score.blocked:
        skip = score.reasons[0].text
    elif score.score < cfg.min_score_to_post:
        skip = f"Score {score.score}/100 sous le seuil de {cfg.min_score_to_post}."
    elif margin is None:
        skip = "Pas de prix de revente de référence : marge impossible à calculer."
    elif margin.net <= 0:
        skip = f"Marge nette de {margin.net:.2f} € : pas rentable."

    return Decision(
        candidate=candidate,
        score=score,
        margin=margin,
        route=r,
        post=skip is None,
        skip_reason=skip,
    )


class SeenStore:
    """Mémorise les annonces déjà traitées pour ne pas les renvoyer."""

    def __init__(self, path: str | Path):
        self._path = Path(path)
        self._ids: set[str] = set()
        if self._path.exists():
            self._ids = set(json.loads(self._path.read_text(encoding="utf-8")))

    def __contains__(self, listing_id: str) -> bool:
        return listing_id in self._ids

    def add(self, listing_id: str) -> None:
        self._ids.add(listing_id)
        self._path.write_text(json.dumps(sorted(self._ids)), encoding="utf-8")
