"""Mots-clés de risque. Les textes sont normalisés (minuscules, sans accents) avant comparaison."""

from __future__ import annotations

import re
import unicodedata


def normalize(text: str) -> str:
    """Minuscules, sans accents, apostrophes et tirets remplacés par des espaces."""
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    text = re.sub(r"[’'`\-_]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# L'objet n'est pas (encore) entre les mains du vendeur : on bloque l'alerte.
# Attention aux faux positifs : « envoi après réception du paiement » est une phrase normale.
# On exige donc un possessif (« après SA réception », « dès MA réception »).
NOT_IN_HAND = [
    r"apres (sa|ma|leur) reception",
    r"apres reception de (ma|mon|sa|son) (commande|colis|precommande)",
    r"des (sa|ma|leur) reception",
    r"pre ?commande",
    r"sur commande",
    r"pas encore (recu|recue|livre|livree|sorti|sortie|disponible)",
    r"en attente de (ma|la|sa) (livraison|reception)",
    r"je (le|la|les) recois",
    r"pas encore en (ma )?possession",
]

# Signaux forts de contrefaçon.
COUNTERFEIT_STRONG = [
    r"\b1 ?[:/] ?1\b",
    r"\breplique\b",
    r"\breplica\b",
    r"\bcopie\b",
    r"\bfake\b",
    r"\bua\b",
    r"\brep\b",
    r"\binspire (de|par)\b",
    r"\bsans (certificat|authenticite)\b",
]

# Signaux faibles : ne prouvent rien, mais méritent une vérification.
SUSPICIOUS_MILD = [
    r"\bstyle\b",
    r"\bsans boite\b",
    r"\bpas de facture\b",
    r"\bsans facture\b",
    r"\bsans ticket\b",
    r"\bsans preuve d achat\b",
    r"\bpas de retour\b",
]

# Paiement en dehors de Vinted : arnaque classique, l'acheteur perd toute protection. Bloquant.
OFF_PLATFORM_PAYMENT = [
    r"\bpaypal\b",
    r"\bvirement\b",
    r"\blydia\b",
    r"\bwero\b",
    r"\bpaylib\b",
    r"\bwestern union\b",
    r"\bcoupons? pcs\b",
    r"\bcarte pcs\b",
    r"(en )?dehors de vinted",
    r"hors (de )?vinted",
    r"sans passer par vinted",
    r"paiement (en )?main propre uniquement",
]

# Contact en dehors de Vinted : souvent le premier pas vers une arnaque.
OFF_PLATFORM_CONTACT_WORDS = [
    r"\bwhats ?app\b",
    r"\btelegram\b",
    r"\bsnap(chat)?\b",
    r"\bsignal\b.*\bmessage",
    r"contacte?z? moi (sur|par|au)",
    r"ecris moi (sur|par|au)",
]
# Ces motifs-là s'appliquent au texte brut (minuscules) : téléphone, e-mail, liens hors Vinted.
OFF_PLATFORM_CONTACT_RAW = [
    r"(?<!\d)(?:\+33\s?|0)[67](?:[\s.\-]?\d{2}){4}(?!\d)",
    r"[a-z0-9._%+\-]+@[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.[a-z]{2,}",
    r"(?:https?://|www\.)(?!(?:www\.)?vinted\.)[^\s]+",
]

URGENCY = [r"\burgent\b", r"\bpremier arrive\b", r"\bdoit partir (vite|aujourd hui|ce soir)\b", r"\bdernier jour\b"]
STOCK_PHOTOS = [r"photos? (d |de |prises? sur )?internet", r"photos? non contractuelles?", r"photos? (du|de|sur le) site"]

_NOT_IN_HAND_RE = [re.compile(p) for p in NOT_IN_HAND]
_PAYMENT_RE = [re.compile(p) for p in OFF_PLATFORM_PAYMENT]
_CONTACT_WORDS_RE = [re.compile(p) for p in OFF_PLATFORM_CONTACT_WORDS]
_CONTACT_RAW_RE = [re.compile(p) for p in OFF_PLATFORM_CONTACT_RAW]
_URGENCY_RE = [re.compile(p) for p in URGENCY]
_STOCK_RE = [re.compile(p) for p in STOCK_PHOTOS]
_STRONG_RE = [re.compile(p) for p in COUNTERFEIT_STRONG]
_MILD_RE = [re.compile(p) for p in SUSPICIOUS_MILD]


def _hits(patterns: list[re.Pattern[str]], text: str) -> list[str]:
    return [m.group(0) for p in patterns if (m := p.search(text))]


def find_not_in_hand(text: str) -> list[str]:
    return _hits(_NOT_IN_HAND_RE, normalize(text))


def find_counterfeit_strong(text: str) -> list[str]:
    return _hits(_STRONG_RE, normalize(text))


def find_suspicious_mild(text: str) -> list[str]:
    return _hits(_MILD_RE, normalize(text))


def find_off_platform_payment(text: str) -> list[str]:
    return _hits(_PAYMENT_RE, normalize(text))


def find_off_platform_contact(text: str) -> list[str]:
    return _hits(_CONTACT_WORDS_RE, normalize(text)) + _hits(_CONTACT_RAW_RE, (text or "").lower())


def find_urgency(text: str) -> list[str]:
    return _hits(_URGENCY_RE, normalize(text))


def find_stock_photos(text: str) -> list[str]:
    return _hits(_STOCK_RE, normalize(text))
