from dataclasses import replace
from datetime import date

from radar.models import Listing, MarketStats, Seller
from radar.scoring import ImageCheckResult, price_gap, score_listing

TODAY = date(2026, 11, 10)

GOOD_SELLER = Seller("ok", rating_count=40, rating_avg=4.9, account_age_days=800, same_brand_listings=2)
PHOTOS = ("a.jpg", "b.jpg", "c.jpg")


def listing(**kw) -> Listing:
    base = dict(
        id="1",
        title="Console portable",
        description="Console testée et fonctionnelle, chargeur d'origine inclus, envoi soigné.",
        price=90.0,
        buyer_total=95.0,
        url="https://example.invalid/1",
        category="retro-3ds-gameboy",
        photos=PHOTOS,
        seller=GOOD_SELLER,
    )
    base.update(kw)
    return Listing(**base)


MARKET = MarketStats(median_sold=120.0, n_sold=25)


def codes(result):
    return {r.code for r in result.reasons}


def test_clean_listing_is_reliable():
    r = score_listing(listing(), MARKET, today=TODAY)
    assert not r.blocked
    assert r.score >= 90
    assert r.label == "Fiable"


def test_price_gap_is_measured_against_sales_not_asking_prices():
    market = MarketStats(median_sold=330.0, n_sold=20, median_asking=500.0, n_asking=36)
    gap = price_gap(listing(buyer_total=189.70), market)
    assert round(gap * 100) == 43  # et non 62 % par rapport aux annonces


def test_gta_controller_case_is_blocked():
    """Le cas réel : « Disponible après sa réception le 19 Novembre », produit pas encore sorti."""
    item = listing(
        title="Manette PS5 GTA VI - Édition Collector",
        description="Neuve, boîte scellée. Disponible après sa réception le 19 Novembre.",
        price=180.0,
        buyer_total=189.70,
        category="playstation",
    )
    market = MarketStats(
        median_sold=330.0, n_sold=3, median_asking=500.0, n_asking=36, official_price=84.99, release_date=date(2026, 11, 19)
    )
    r = score_listing(item, market, today=TODAY)
    assert r.blocked and r.score == 0
    assert {"not_released", "not_in_hand"} <= codes(r)


def test_not_in_hand_alone_blocks_even_after_release_date():
    item = listing(description="Disponible après sa réception, je l'ai précommandée, envoi rapide.")
    market = MarketStats(median_sold=120.0, n_sold=25, release_date=date(2026, 1, 1))
    r = score_listing(item, market, today=TODAY)
    assert r.blocked and "not_in_hand" in codes(r)
    assert "not_released" not in codes(r)


def test_normal_shipping_phrase_does_not_block():
    item = listing(description="Console testée, j'expédie dès réception du paiement, emballage soigné.")
    assert not score_listing(item, MARKET, today=TODAY).blocked


def test_suspiciously_low_price_on_valuable_item_is_penalised():
    r = score_listing(listing(buyer_total=60.0), MARKET, today=TODAY)  # 50 % sous les ventes
    assert "gap_suspicious" in codes(r)
    assert r.score < 90
    r2 = score_listing(listing(buyer_total=30.0), MARKET, today=TODAY)  # 75 % sous les ventes
    assert "gap_extreme" in codes(r2)
    assert r2.score < r.score


def test_big_gap_on_cheap_item_is_not_a_risk_signal():
    market = MarketStats(median_sold=34.0, n_sold=15)
    r = score_listing(listing(buyer_total=16.0), market, today=TODAY)  # 53 % sous les ventes
    assert not {"gap_suspicious", "gap_extreme"} & codes(r)


def test_counterfeit_keywords_and_new_seller_drop_the_score():
    item = listing(
        title="Baskets style 1:1",
        description="Qualité UA, sans boîte, pas de facture.",
        photos=("a.jpg",),
        seller=Seller("new", rating_count=0, account_age_days=5, same_brand_listings=14),
    )
    r = score_listing(item, MARKET, today=TODAY)
    assert {"counterfeit", "seller_no_reviews", "seller_new", "seller_stock", "few_photos"} <= codes(r)
    assert r.score < 20 and r.label == "Risque élevé"


def test_few_sales_make_the_reference_weak():
    r = score_listing(listing(), MarketStats(median_sold=120.0, n_sold=2), today=TODAY)
    assert "few_sales" in codes(r)


def test_missing_reference_is_penalised():
    r = score_listing(listing(), MarketStats(), today=TODAY)
    assert "no_reference" in codes(r)


def test_speculative_reference_vs_official_price():
    market = MarketStats(median_sold=330.0, n_sold=25, official_price=84.99)
    assert "speculative" in codes(score_listing(listing(buyer_total=300.0), market, today=TODAY))


def test_reused_photo_blocks_the_alert():
    class Checker:
        def check(self, urls):
            return ImageCheckResult(reused=True)

    r = score_listing(listing(), MARKET, today=TODAY, image_checker=Checker())
    assert r.blocked and "photo_reused" in codes(r)


def test_unverified_photos_do_not_penalise():
    class Checker:
        def check(self, urls):
            return ImageCheckResult(reused=None)

    r = score_listing(listing(), MARKET, today=TODAY, image_checker=Checker())
    assert not r.blocked and r.score >= 90


def test_score_is_clamped_between_0_and_100():
    r = score_listing(replace(listing(), seller=None, photos=(), description=""), MarketStats(), today=TODAY)
    assert 0 <= r.score <= 100
