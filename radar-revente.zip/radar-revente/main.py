"""Point d'entrée : python main.py --config config.json"""

from __future__ import annotations

import argparse
import logging

from radar.bot import RadarBot
from radar.config import discord_token, load_config
from radar.sources import FileSource

SAMPLE = "data/sample_candidates.json"


def main() -> None:
    parser = argparse.ArgumentParser(description="Radar Revente")
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config(args.config)

    # Source de démonstration. Remplacez-la par votre propre ListingSource (voir radar/sources.py).
    bot = RadarBot(cfg, source=FileSource(SAMPLE), sample_path=SAMPLE)
    bot.run(discord_token())


if __name__ == "__main__":
    main()
