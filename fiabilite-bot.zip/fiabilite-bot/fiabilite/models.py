"""Données d'entrée de l'évaluation. Tout est optionnel sauf le titre et le prix :
moins on en sait, plus l'évaluation le signale (champ « infos manquantes »)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Optional


@dataclass(frozen=True)
class Vendeur:
    pseudo: Optional[str] = None
    nb_avis: Optional[int] = None
    note: Optional[float] = None  # sur 5
    anciennete_jours: Optional[int] = None
    nb_articles_meme_marque: Optional[int] = None


@dataclass(frozen=True)
class Marche:
    mediane_ventes: Optional[float] = None  # médiane des PRIX DE VENTE observés (ou estimation de revente)
    nb_ventes: int = 0  # nombre de ventes derrière la médiane ; 0 = estimation non sourcée
    mediane_annonces: Optional[float] = None  # médiane des prix DEMANDÉS
    nb_annonces: int = 0
    prix_neuf: Optional[float] = None
    date_sortie: Optional[date] = None


@dataclass(frozen=True)
class Annonce:
    titre: str
    prix_total: float  # ce que l'acheteur paie, frais de protection inclus
    description: str = ""
    prix: Optional[float] = None  # prix affiché de l'article (sinon = prix_total)
    id: Optional[str] = None
    url: Optional[str] = None
    categorie: Optional[str] = None
    marque: Optional[str] = None
    etat: Optional[str] = None
    photos: tuple[str, ...] = field(default_factory=tuple)
    nb_photos: Optional[int] = None  # si absent : len(photos) si des photos sont fournies, sinon inconnu
    vendeur: Optional[Vendeur] = None

    @property
    def prix_article(self) -> float:
        return self.prix if self.prix is not None else self.prix_total

    @property
    def nombre_photos(self) -> Optional[int]:
        if self.nb_photos is not None:
            return self.nb_photos
        return len(self.photos) if self.photos else None
