# Radar Revente — bot Discord et filtre de fiabilité

Un bot Discord (Python, `discord.py`) qui publie des alertes d'achat-revente **seulement si elles passent un filtre de fiabilité**, avec une marge calculée honnêtement (frais de revente et cotisations inclus).

## Ce que fait le projet

- **Score de confiance (0 à 100)** pour chaque annonce, avec les raisons détaillées.
- **Blocage automatique** des annonces dont l'objet n'est pas chez le vendeur (« après sa réception le… », précommande, produit pas encore sorti) et des photos déjà vues ailleurs.
- **Prix comparé aux ventes réelles**, pas aux annonces. Un trop gros écart sur un objet de valeur fait baisser le score.
- **Marge détaillée** : avant et après cotisations, avec des frais de revente par catégorie.
- **Carte d'alerte Discord** avec boutons : ouvrir l'annonce, Google Lens, prix officiel, checklist adaptée à la catégorie, message prêt à envoyer au vendeur, estimation de marge personnalisée, signalement.
- **Routage** vers un salon par catégorie ou par marque, avec mention de **rôles** (jamais `@everyone`).
- Commande `/demo` (administrateurs) pour prévisualiser les cartes sans aucune source de données.

## Ce que le projet ne fait pas (volontairement)

- **Pas d'achat automatique.** Le bouton « Ouvrir l'annonce » mène à la page Vinted, et c'est l'abonné qui confirme.
- **Pas de récupération des annonces Vinted.** Vinted n'a pas d'API publique, et ses conditions d'utilisation limitent l'accès automatisé. Vérifiez-les, puis branchez votre propre source en implémentant `ListingSource.fetch_new()` dans `radar/sources.py`.
- **Pas de recherche d'image inversée incluse.** L'interface `ImageChecker` (dans `radar/scoring.py`) est prête : une photo trouvée ailleurs bloque l'alerte.

## Installation

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp config.example.json config.json   # puis remplissez vos identifiants de salons et de rôles
export DISCORD_TOKEN="votre_token"   # ne le mettez jamais dans un fichier du dépôt
python main.py --config config.json
```

Dans le portail développeur Discord, invitez le bot avec les permissions « Envoyer des messages », « Intégrer des liens » et « Utiliser les commandes d'application ».

## Configuration (`config.json`)

| Clé | Rôle |
|---|---|
| `guild_id` | Identifiant du serveur (synchronise les commandes immédiatement) |
| `min_score_to_post` | Score minimal pour publier une alerte (60 par défaut) |
| `cotisation_rate` | Taux de cotisations sur le prix de revente (12,3 % par défaut, **à confirmer sur urssaf.fr**) |
| `micro_entreprise` | `false` pour ne pas déduire de cotisations |
| `default_resale_costs` / `resale_costs` | Frais de revente estimés, par défaut et par catégorie |
| `channels` | `"categorie"` ou `"categorie/marque"` → identifiant du salon |
| `roles` | Même clés → identifiant du rôle à mentionner |

Le routage essaie d'abord `categorie/marque`, puis `categorie`.

## Brancher votre source de données

```python
from radar.sources import ListingSource
from radar.models import Candidate

class MaSource(ListingSource):
    async def fetch_new(self) -> list[Candidate]:
        ...  # retourne des Candidate(listing=..., market=...)
```

Chaque `Candidate` contient l'annonce et les statistiques de marché (`MarketStats`) : médiane des **ventes** et leur nombre, médiane des annonces actives, prix officiel et date de sortie si l'objet n'est pas encore sorti. Remplacez ensuite `FileSource(SAMPLE)` par votre source dans `main.py`.

Deux points à vérifier dans vos propres données : comment vous détectez qu'une annonce a été **vendue** (une annonce qui disparaît n'est pas forcément vendue), et le **nombre de ventes** derrière chaque médiane.

## Comment le score est calculé

Le score part de 100. Les signaux bloquants mettent l'alerte à 0, les autres retirent des points.

| Signal | Effet |
|---|---|
| Produit pas encore sorti, ou « après sa réception », précommande | Bloquant |
| Photo déjà présente ailleurs (si un `ImageChecker` est branché) | Bloquant |
| Mots-clés de contrefaçon (`1:1`, `UA`, `réplique`...) | −50 |
| Prix 40 à 60 % sous les ventes (objet d'au moins 50 €) | −25 |
| Prix plus de 60 % sous les ventes (objet d'au moins 50 €) | −35 |
| Médiane basée sur moins de 5 ventes | −15 |
| Vendeur sans avis / compte récent / beaucoup d'articles de la même marque | −20 / −15 / −15 |
| Référence spéculative (revente plus de 2x le prix officiel) | −15 |

Tous les seuils sont dans `ScoringConfig` (`radar/scoring.py`) et les mots-clés dans `radar/keywords.py`. Les règles sont volontairement prudentes : elles évitent les faux positifs comme « j'expédie dès réception du paiement ».

## Tests

```bash
python -m pytest
```

Les tests couvrent le cas réel de la manette annoncée « après sa réception », le calcul de marge (89 € nets sur l'exemple à 129 € bruts), le routage et la carte d'alerte.

## Limites connues

- Les boutons interactifs ne survivent pas à un redémarrage du bot : une alerte déjà publiée ne répond plus. Pour les rendre persistants, stockez les décisions dans une base de données et utilisez des vues persistantes avec `custom_id`.
- Les données de `data/sample_candidates.json` sont fictives, et les URL (`example.invalid`) ne mènent nulle part.
- Les taux (cotisations, seuils) sont des ordres de grandeur : à faire valider par un expert-comptable.
- Une marge affichée reste une **estimation, pas une garantie de gain** : à rappeler dans vos CGV.
