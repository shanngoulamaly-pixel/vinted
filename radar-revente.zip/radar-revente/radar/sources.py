"""Sources d'annonces.

IMPORTANT : ce projet ne contient volontairement AUCUNE récupération des annonces Vinted.
Vinted n'a pas d'API publique et ses conditions d'utilisation limitent l'accès automatisé :
vérifiez-les, et décidez vous-mêmes de la source de données à brancher.
Il suffit d'implémenter `ListingSource.fetch_new()` pour alimenter le bot.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from datetime import date
from pathlib import Path

from .models import Candidate, Listing, MarketStats, Seller


class ListingSource(ABC):
    @abstractmethod
    async def fetch_new(self) -> list[Candidate]:
        """Retourne les nouvelles annonces avec leurs statistiques de marché."""


def candidate_from_dict(raw: dict) -> Candidate:
    l = dict(raw["listing"])
    seller = Seller(**l.pop("seller")) if l.get("seller") else None
    l["photos"] = tuple(l.get("photos", ()))
    listing = Listing(seller=seller, **l)

    m = dict(raw.get("market", {}))
    if m.get("release_date"):
        m["release_date"] = date.fromisoformat(m["release_date"])
    return Candidate(listing=listing, market=MarketStats(**m))


def load_candidates(path: str | Path) -> list[Candidate]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return [candidate_from_dict(item) for item in raw]


class FileSource(ListingSource):
    """Source de démonstration : renvoie une fois chaque annonce d'un fichier JSON."""

    def __init__(self, path: str | Path):
        self._pending = load_candidates(path)

    async def fetch_new(self) -> list[Candidate]:
        batch, self._pending = self._pending, []
        return batch
