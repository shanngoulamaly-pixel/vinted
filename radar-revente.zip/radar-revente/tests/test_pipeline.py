import json
from datetime import date

from radar.config import BotConfig, load_config
from radar.pipeline import SeenStore, evaluate
from radar.sources import load_candidates

SAMPLE = "data/sample_candidates.json"
TODAY = date(2026, 11, 10)
CFG = BotConfig(resale_costs={"playstation": 11.0}, channels={"retro-3ds-gameboy": 1, "jeans": 2}, roles={"jeans": 9})


def by_id():
    return {c.listing.id: evaluate(c, CFG, today=TODAY) for c in load_candidates(SAMPLE)}


def test_sample_decisions():
    d = by_id()
    assert d["demo-001"].post and d["demo-004"].post
    assert not d["demo-002"].post  # manette pas encore reçue : bloquée
    assert not d["demo-003"].post  # contrefaçon probable


def test_blocked_alert_explains_why():
    d = by_id()["demo-002"]
    assert d.score.blocked
    assert "pas encore sorti" in d.skip_reason.lower() or "pas l'objet" in d.skip_reason.lower()


def test_margin_uses_resale_costs_per_category():
    d = by_id()["demo-002"]
    assert d.margin.resale_costs == 11.0
    assert d.margin.gross == 129.30  # le chiffre affiché par l'ancienne alerte


def test_unprofitable_alert_is_skipped():
    cand = load_candidates(SAMPLE)[0]
    from dataclasses import replace

    pricey = replace(cand, listing=replace(cand.listing, buyer_total=104.0))  # ~ aucune marge
    d = evaluate(pricey, CFG, today=TODAY)
    assert not d.post and "pas rentable" in d.skip_reason


def test_routing_is_applied():
    d = by_id()["demo-004"]
    assert d.route.channel_id == 2 and d.route.role_ids == (9,)


def test_seen_store_persists(tmp_path):
    path = tmp_path / "seen.json"
    store = SeenStore(path)
    assert "a" not in store
    store.add("a")
    assert "a" in SeenStore(path)


def test_load_config(tmp_path):
    path = tmp_path / "c.json"
    path.write_text(json.dumps({"min_score_to_post": 70, "channels": {"x": 1}}), encoding="utf-8")
    cfg = load_config(path)
    assert cfg.min_score_to_post == 70 and cfg.channels == {"x": 1} and cfg.cotisation_rate == 0.123
