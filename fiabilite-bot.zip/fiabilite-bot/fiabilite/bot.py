"""Bot Discord : commande /verifier pour vérifier une annonce à la main.

Le bot ne récupère aucune annonce lui-même : on lui décrit l'annonce, il rend un verdict.
"""

from __future__ import annotations

import logging
from typing import Any, Optional
from urllib.parse import quote

import discord
from discord import app_commands

from .api import ErreurEntree, Options, evaluer

log = logging.getLogger("fiabilite.bot")

CATEGORIES = [
    ("PlayStation", "playstation"), ("Nintendo Switch", "nintendo-switch"), ("Rétro / 3DS / Game Boy", "retro-3ds-gameboy"),
    ("High-tech", "objets-high-tech"), ("Vêtements", "vetements"), ("Jeans", "jeans"), ("Chaussures", "chaussures"),
    ("Sacs", "sacs"), ("Luxe", "luxe"), ("Beauté", "beaute"), ("LEGO", "lego"), ("Playmobil", "playmobil"),
    ("Cartes Pokémon", "cartes-pokemon"), ("Cartes gradées", "cartes-gradees-et-non-gradees"), ("One Piece", "one-piece"),
    ("Vintage / déco", "vintage-deco"), ("Autre", "autre"),
]
COULEURS = {"fiable": 0x2ECC71, "a_verifier": 0xF39C12, "risque_eleve": 0xE74C3C, "a_eviter": 0x8B0000}
PICTOS = {"fiable": "✅", "a_verifier": "⚠️", "risque_eleve": "⛔", "a_eviter": "⛔"}


def est_url(v: Optional[str]) -> bool:
    return bool(v) and v.startswith(("http://", "https://"))


def barre(score: int) -> str:
    n = max(0, min(10, round(score / 10)))
    return "█" * n + "░" * (10 - n)


def _couper(lignes: list[str], limite: int = 1024) -> str:
    texte = ""
    for ligne in lignes:
        if len(texte) + len(ligne) + 1 > limite - 4:
            return texte + "\n…"
        texte += ("\n" if texte else "") + ligne
    return texte


def carte(resultat: dict[str, Any], titre: str, url: Optional[str] = None, photo: Optional[str] = None) -> discord.Embed:
    v = resultat["verdict"]
    e = discord.Embed(
        title=f"Vérification : {titre}"[:256],
        url=url if est_url(url) else None,
        color=COULEURS[v],
        description=f"{PICTOS[v]} **{resultat['libelle']}** — score **{resultat['score']}/100**\n`{barre(resultat['score'])}`",
    )
    raisons = [f"• {r['texte']}" for r in resultat["raisons"]]
    e.add_field(name="Points de vigilance", value=_couper(raisons) or "Aucun signal de risque détecté.", inline=False)

    prix = []
    if resultat["ecart_prix_pct"] is not None:
        sens = "sous" if resultat["ecart_prix_pct"] >= 0 else "au-dessus de"
        prix.append(f"Écart : **{abs(resultat['ecart_prix_pct'])} %** {sens} la référence")
    if m := resultat["marge"]:
        prix.append(f"Marge si revendu {m['prix_revente']:.0f} € : **{m['brute']:+.2f} €** avant cotisations, "
                    f"**{m['nette']:+.2f} €** après (dont {m['frais_revente']:.0f} € de frais)")
    if prix:
        e.add_field(name="Prix", value=_couper(prix), inline=False)
    if resultat["infos_manquantes"]:
        e.add_field(name="Pour une analyse plus sûre, il manque",
                    value=_couper([f"• {x}" for x in resultat["infos_manquantes"]]), inline=False)
    if est_url(photo):
        e.set_image(url=photo)
    e.set_footer(text=resultat["avertissement"])
    return e


class VueVerification(discord.ui.View):
    def __init__(self, resultat: dict[str, Any], url: Optional[str], photo: Optional[str]):
        super().__init__(timeout=3600)
        self.resultat = resultat
        if est_url(url):
            self.add_item(discord.ui.Button(style=discord.ButtonStyle.link, label="Ouvrir l'annonce", url=url, row=0))
        if est_url(photo):
            lens = f"https://lens.google.com/uploadbyurl?url={quote(photo, safe='')}"
            self.add_item(discord.ui.Button(style=discord.ButtonStyle.link, label="Photo : Google Lens", url=lens, row=0))

    @discord.ui.button(label="Checklist", style=discord.ButtonStyle.secondary, row=1)
    async def bouton_checklist(self, interaction: discord.Interaction, _: discord.ui.Button):
        items = "\n".join(f"• {x}" for x in self.resultat["checklist"])
        await interaction.response.send_message(f"**À vérifier avant d'acheter**\n{items}", ephemeral=True)

    @discord.ui.button(label="Message au vendeur", style=discord.ButtonStyle.secondary, row=1)
    async def bouton_message(self, interaction: discord.Interaction, _: discord.ui.Button):
        await interaction.response.send_message(
            f"Copie-colle ce message :\n```\n{self.resultat['message_vendeur']}\n```", ephemeral=True
        )


class FenetreAnnonce(discord.ui.Modal, title="Vérifier une annonce"):
    titre = discord.ui.TextInput(label="Titre de l'annonce", max_length=200)
    description = discord.ui.TextInput(
        label="Description (copie-colle l'annonce)", style=discord.TextStyle.paragraph, max_length=4000, required=False
    )
    lien = discord.ui.TextInput(label="Lien de l'annonce (facultatif)", required=False, max_length=500)

    def __init__(self, donnees: dict[str, Any], photo: Optional[str], prive: bool, options: Options):
        super().__init__()
        self.donnees, self.photo, self.prive, self.options = donnees, photo, prive, options

    async def on_submit(self, interaction: discord.Interaction) -> None:
        data = dict(self.donnees, titre=self.titre.value, description=self.description.value, url=self.lien.value or None)
        try:
            resultat = evaluer(data, self.options)
        except ErreurEntree as e:
            await interaction.response.send_message(f"Impossible d'évaluer : {e}", ephemeral=True)
            return
        await interaction.response.send_message(
            embed=carte(resultat, self.titre.value, self.lien.value, self.photo),
            view=VueVerification(resultat, self.lien.value, self.photo),
            ephemeral=self.prive,
        )


class BotFiabilite(discord.Client):
    def __init__(self, options: Options = Options()):
        super().__init__(intents=discord.Intents.default())
        self.options = options
        self.tree = app_commands.CommandTree(self)
        self._synchro_faite = False

        @self.tree.command(name="verifier", description="Vérifie la fiabilité d'une annonce d'occasion")
        @app_commands.describe(
            categorie="Catégorie de l'article (pour la checklist)",
            prix_total="Ce que tu paies, frais de protection inclus (€)",
            revente="Prix auquel ce modèle se vend réellement (€), pour juger le prix et la marge",
            ventes_observees="Nombre de ventes sur lesquelles repose ce prix de revente",
            prix_neuf="Prix neuf officiel (€), si tu le connais",
            avis_vendeur="Nombre d'avis du vendeur",
            note_vendeur="Note du vendeur sur 5",
            anciennete_jours="Ancienneté du compte du vendeur, en jours",
            nb_photos="Nombre de photos dans l'annonce",
            photo="Une photo de l'annonce (pour Google Lens)",
            prive="Réponse visible seulement par toi",
        )
        @app_commands.choices(categorie=[app_commands.Choice(name=n, value=v) for n, v in CATEGORIES])
        async def verifier(
            interaction: discord.Interaction,
            categorie: app_commands.Choice[str],
            prix_total: app_commands.Range[float, 0.0, 100000.0],
            revente: Optional[app_commands.Range[float, 0.0, 100000.0]] = None,
            ventes_observees: Optional[app_commands.Range[int, 0, 100000]] = None,
            prix_neuf: Optional[app_commands.Range[float, 0.0, 100000.0]] = None,
            avis_vendeur: Optional[app_commands.Range[int, 0, 1000000]] = None,
            note_vendeur: Optional[app_commands.Range[float, 0.0, 5.0]] = None,
            anciennete_jours: Optional[app_commands.Range[int, 0, 10000]] = None,
            nb_photos: Optional[app_commands.Range[int, 0, 30]] = None,
            photo: Optional[discord.Attachment] = None,
            prive: bool = False,
        ):
            donnees = {
                "categorie": categorie.value if categorie.value != "autre" else None,
                "prix_total": prix_total,
                "nb_photos": nb_photos,
                "photos": [photo.url] if photo else [],
                "vendeur": {"nb_avis": avis_vendeur, "note": note_vendeur, "anciennete_jours": anciennete_jours},
                "marche": {"mediane_ventes": revente, "nb_ventes": ventes_observees or 0, "prix_neuf": prix_neuf},
            }
            await interaction.response.send_modal(
                FenetreAnnonce(donnees, photo.url if photo else None, prive, self.options)
            )

    async def _synchroniser(self, guild: discord.abc.Snowflake) -> None:
        self.tree.copy_global_to(guild=guild)
        await self.tree.sync(guild=guild)

    async def on_ready(self) -> None:
        # Commandes synchronisées serveur par serveur : visibles tout de suite, sans attendre.
        if not self._synchro_faite:
            for g in self.guilds:
                await self._synchroniser(g)
            self._synchro_faite = True
        log.info("Bot connecté : %s (%d serveur(s))", self.user, len(self.guilds))

    async def on_guild_join(self, guild: discord.Guild) -> None:
        await self._synchroniser(guild)
