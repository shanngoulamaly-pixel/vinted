"""Carte d'alerte Discord et boutons.

Aucun bouton n'achète quoi que ce soit : « Ouvrir l'annonce » est un lien vers la page Vinted,
et c'est l'abonné qui confirme lui-même l'achat.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from urllib.parse import quote

import discord

from .checklists import checklist_for, seller_message
from .config import BotConfig
from .margin import compute_margin
from .pipeline import Decision
from .scoring import price_gap

GREEN, ORANGE, RED = 0x2ECC71, 0xF39C12, 0xE74C3C


def score_bar(score: int) -> str:
    filled = max(0, min(10, round(score / 10)))
    return "█" * filled + "░" * (10 - filled)


def _color(score: int) -> int:
    return GREEN if score >= 75 else ORANGE if score >= 50 else RED


def build_embed(decision: Decision) -> discord.Embed:
    cand, score, margin = decision.candidate, decision.score, decision.margin
    l, m = cand.listing, cand.market

    embed = discord.Embed(title=l.title[:250], url=l.url, color=_color(score.score))
    meta = " · ".join(x for x in (l.brand, l.condition, f"♥ {l.favourites}") if x)
    embed.description = f"**{l.category}** · {meta}"

    embed.add_field(name="Tu paies", value=f"**{l.buyer_total:.2f} €**\n*frais inclus*", inline=True)

    if margin:
        embed.add_field(name="Revente visée", value=f"**{margin.resale_price:.0f} €**", inline=True)
        embed.add_field(
            name="Marge",
            value=(
                f"**{margin.gross:+.2f} €** avant cotisations\n"
                f"**{margin.net:+.2f} €** après cotisations\n"
                f"*dont {margin.resale_costs:.0f} € de frais de revente estimés*"
            ),
            inline=True,
        )
    else:
        embed.add_field(name="Marge", value="Pas de prix de revente de référence.", inline=False)

    # Marché : on met en avant l'écart avec les VENTES, pas avec les annonces.
    lines = []
    gap = price_gap(l, m)
    if m.median_sold:
        extra = f" · écart **{gap * 100:.0f} %** sous les ventes" if gap and gap > 0 else ""
        lines.append(f"Ventes observées : **{m.median_sold:.0f} €** (médiane de {m.n_sold} ventes){extra}")
    if m.median_asking:
        lines.append(f"Annonces actives : {m.median_asking:.0f} € (prix demandés, pas payés)")
    if m.official_price:
        lines.append(f"Prix officiel : {m.official_price:.2f} €")
    if lines:
        embed.add_field(name="Marché", value="\n".join(lines), inline=False)

    top = [f"• {r.text}" for r in score.reasons[:3]]
    conf = f"`{score_bar(score.score)}` **{score.score}/100** — {score.label}"
    if top:
        conf += "\n" + "\n".join(top)
    embed.add_field(name="Confiance", value=conf[:1024], inline=False)

    if l.photos:
        embed.set_image(url=l.photos[0])
    embed.set_footer(text="Estimation, pas une garantie de gain. Vérifie l'annonce avant d'acheter.")
    return embed


class MarginModal(discord.ui.Modal, title="Estimer ma marge"):
    def __init__(self, decision: Decision, cfg: BotConfig):
        super().__init__()
        self.decision, self.cfg = decision, cfg
        l, m = decision.candidate.listing, decision.candidate.market
        self.resale = discord.ui.TextInput(
            label="Prix de revente visé (€)", default=f"{m.median_sold:.0f}" if m.median_sold else ""
        )
        self.costs = discord.ui.TextInput(
            label="Frais de revente : port, emballage (€)", default=f"{cfg.costs_for(l.category):.0f}"
        )
        self.add_item(self.resale)
        self.add_item(self.costs)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            resale = float(self.resale.value.replace(",", ".").strip())
            costs = float(self.costs.value.replace(",", ".").strip())
        except ValueError:
            await interaction.response.send_message("Entre des nombres, par exemple 120 ou 4,5.", ephemeral=True)
            return
        l = self.decision.candidate.listing
        res = compute_margin(l.buyer_total, resale, costs, self.cfg.cotisation_rate, self.cfg.micro_entreprise)
        await interaction.response.send_message(
            f"**Achat** {res.buy_total:.2f} € → **revente** {res.resale_price:.2f} € (frais {res.resale_costs:.2f} €)\n"
            f"Marge avant cotisations : **{res.gross:+.2f} €**\n"
            f"Cotisations ({self.cfg.cotisation_rate * 100:.1f} % du prix de revente) : −{res.cotisations:.2f} €\n"
            f"Marge après cotisations : **{res.net:+.2f} €**",
            ephemeral=True,
        )


class AlertView(discord.ui.View):
    def __init__(self, decision: Decision, cfg: BotConfig):
        super().__init__(timeout=None)
        self.decision, self.cfg = decision, cfg
        l, m = decision.candidate.listing, decision.candidate.market

        self.add_item(discord.ui.Button(style=discord.ButtonStyle.link, label="Ouvrir l'annonce", url=l.url, row=0))
        if l.photos:
            lens = f"https://lens.google.com/uploadbyurl?url={quote(l.photos[0], safe='')}"
            self.add_item(discord.ui.Button(style=discord.ButtonStyle.link, label="Photo : Google Lens", url=lens, row=0))
        if m.official_url:
            self.add_item(
                discord.ui.Button(style=discord.ButtonStyle.link, label="Prix officiel", url=m.official_url, row=0)
            )

    @discord.ui.button(label="Checklist", style=discord.ButtonStyle.secondary, row=1)
    async def checklist(self, interaction: discord.Interaction, button: discord.ui.Button):
        l = self.decision.candidate.listing
        items = "\n".join(f"• {x}" for x in checklist_for(l.category))
        await interaction.response.send_message(f"**À vérifier avant d'acheter**\n{items}", ephemeral=True)

    @discord.ui.button(label="Message vendeur", style=discord.ButtonStyle.secondary, row=1)
    async def message(self, interaction: discord.Interaction, button: discord.ui.Button):
        text = seller_message(self.decision.candidate.listing)
        await interaction.response.send_message(f"Copie-colle ce message :\n```\n{text}\n```", ephemeral=True)

    @discord.ui.button(label="Estimer ma marge", style=discord.ButtonStyle.secondary, row=1)
    async def margin(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(MarginModal(self.decision, self.cfg))

    @discord.ui.button(label="Signaler", style=discord.ButtonStyle.danger, row=1)
    async def report(self, interaction: discord.Interaction, button: discord.ui.Button):
        entry = {
            "ts": int(time.time()),
            "listing_id": self.decision.candidate.listing.id,
            "user_id": interaction.user.id,
            "score": self.decision.score.score,
        }
        with Path(self.cfg.reports_path).open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        await interaction.response.send_message(
            "Merci, l'alerte est signalée à l'équipe. Elle servira à améliorer le filtre.", ephemeral=True
        )
