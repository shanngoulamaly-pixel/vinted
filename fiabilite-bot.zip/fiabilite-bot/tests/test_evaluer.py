from datetime import date

import pytest

from fiabilite import ErreurEntree, Options, evaluer

AUJ = date(2026, 11, 10)

BONNE = {
    "id": "ok-1",
    "titre": "Console portable avec 3 jeux",
    "description": "Console testée et fonctionnelle, chargeur d'origine inclus, envoi soigné sous 48h.",
    "prix": 62,
    "prix_total": 65.4,
    "categorie": "retro-3ds-gameboy",
    "nb_photos": 4,
    "vendeur": {"nb_avis": 48, "note": 4.9, "anciennete_jours": 900},
    "marche": {"mediane_ventes": 105, "nb_ventes": 22},
}


def codes(res):
    return {r["code"] for r in res["raisons"]}


def test_annonce_propre_est_fiable_et_publiable():
    res = evaluer(BONNE, aujourdhui=AUJ)
    assert res["verdict"] == "fiable" and res["publier"] and not res["bloquee"]
    assert res["score"] >= 90
    assert res["id"] == "ok-1"
    assert res["ecart_prix_pct"] == 38
    assert res["marge"]["nette"] == pytest.approx(105 - 65.4 - 5 - 105 * 0.123, abs=0.01)
    assert res["infos_manquantes"] == []
    assert any("fonctionnement" in c for c in res["checklist"])


def test_cas_reel_de_la_manette_gta():
    res = evaluer({
        "titre": "Manette PS5 GTA VI - Édition Collector",
        "description": "Neuve avec étiquette. Disponible après sa réception le 19 Novembre.",
        "prix": 180, "prix_total": 189.70, "categorie": "playstation", "nb_photos": 3,
        "vendeur": {"nb_avis": 12, "note": 4.8},
        "marche": {"mediane_ventes": 330, "nb_ventes": 3, "mediane_annonces": 500, "nb_annonces": 36,
                   "prix_neuf": 84.99, "date_sortie": "2026-11-19"},
        "revente": {"frais": 11},
    }, aujourdhui=AUJ)
    assert res["verdict"] == "a_eviter" and res["score"] == 0 and not res["publier"]
    assert {"pas_sorti", "pas_en_main"} <= codes(res)
    assert res["ecart_prix_pct"] == 43  # mesuré sur les ventes, pas sur les annonces à 500 €
    assert res["marge"]["brute"] == 129.30 and res["marge"]["nette"] == 88.71


def test_paiement_hors_vinted_bloque():
    res = evaluer(dict(BONNE, description="Très bon état. Paiement par virement ou PayPal entre amis, merci."), aujourdhui=AUJ)
    assert res["bloquee"] and "paiement_hors_vinted" in codes(res)


def test_contact_hors_vinted_fait_chuter_le_score():
    res = evaluer(dict(BONNE, description="Très bon état, plus de photos sur WhatsApp au 06 12 34 56 78."), aujourdhui=AUJ)
    assert "contact_hors_vinted" in codes(res) and res["score"] <= 70


def test_contrefacon_et_compte_neuf():
    res = evaluer({
        "titre": "Baskets style 1:1", "description": "Qualité UA, sans boîte, pas de facture. Urgent.",
        "prix_total": 48.2, "categorie": "chaussures", "nb_photos": 1,
        "vendeur": {"nb_avis": 0, "anciennete_jours": 5, "nb_articles_meme_marque": 14},
        "marche": {"mediane_ventes": 140, "nb_ventes": 18},
    }, aujourdhui=AUJ)
    assert res["verdict"] == "risque_eleve" and not res["publier"]
    assert {"contrefacon", "vendeur_sans_avis", "compte_recent", "stock_meme_marque",
            "peu_de_photos", "combinaison_arnaque", "urgence"} <= codes(res)


def test_infos_manquantes_et_valeurs_inconnues_non_penalisees_a_tort():
    res = evaluer({"titre": "Veste en jean", "prix_total": 16.1}, aujourdhui=AUJ)
    assert "peu_de_photos" not in codes(res)  # nombre de photos inconnu : pas de pénalité
    assert {"vendeur_inconnu", "pas_de_reference", "description_courte"} <= codes(res)
    assert "profil du vendeur (avis, note, ancienneté)" in res["infos_manquantes"]
    assert res["marge"] is None


def test_vendeur_partiel():
    res = evaluer(dict(BONNE, vendeur={"note": 4.1}), aujourdhui=AUJ)
    assert "vendeur_note_basse" in codes(res)
    assert "vendeur_sans_avis" not in codes(res)  # nombre d'avis inconnu, pas « zéro avis »


def test_reference_estimee_sans_ventes():
    res = evaluer(dict(BONNE, marche={"mediane_ventes": 105}), aujourdhui=AUJ)
    assert "reference_estimee" in codes(res)
    assert "nombre de ventes derrière le prix de référence" in res["infos_manquantes"]


def test_seuil_de_publication_configurable():
    res = evaluer(dict(BONNE, nb_photos=1), Options(seuil_publication=95), aujourdhui=AUJ)
    assert res["score"] < 95 and not res["publier"]


def test_nombres_en_texte_acceptes():
    res = evaluer(dict(BONNE, prix_total="65,40 €"), aujourdhui=AUJ)
    assert res["ecart_prix_pct"] == 38


@pytest.mark.parametrize("data, message", [
    ({"prix_total": 10}, "titre"),
    ({"titre": "x"}, "prix_total"),
    ({"titre": "x", "prix_total": "abc"}, "nombre"),
    ({"titre": "x", "prix_total": -3}, "négatif"),
    ({"titre": "x", "prix_total": 3, "vendeur": {"note": 9}}, "sur 5"),
    ({"titre": "x", "prix_total": 3, "marche": {"date_sortie": "19/11/2026"}}, "AAAA-MM-JJ"),
    ("pas un objet", "objet JSON"),
])
def test_erreurs_lisibles(data, message):
    with pytest.raises(ErreurEntree, match=message):
        evaluer(data, aujourdhui=AUJ)
