"""Mots-clés de risque. Les textes sont normalisés (minuscules, sans accents) avant comparaison."""

from __future__ import annotations

import re
import unicodedata


def normalize(text: str) -> str:
    """Minuscules, sans accents, apostrophes et tirets remplacés par des espaces."""
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    text = re.sub(r"[’'`\-_]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# L'objet n'est pas (encore) entre les mains du vendeur : on bloque l'alerte.
# Attention aux faux positifs : « envoi après réception du paiement » est une phrase normale.
# On exige donc un possessif (« après SA réception », « dès MA réception »).
NOT_IN_HAND = [
    r"apres (sa|ma|leur) reception",
    r"apres reception de (ma|mon|sa|son) (commande|colis|precommande)",
    r"des (sa|ma|leur) reception",
    r"pre ?commande",
    r"sur commande",
    r"pas encore (recu|recue|livre|livree|sorti|sortie|disponible)",
    r"en attente de (ma|la|sa) (livraison|reception)",
    r"je (le|la|les) recois",
    r"pas encore en (ma )?possession",
]

# Signaux forts de contrefaçon.
COUNTERFEIT_STRONG = [
    r"\b1 ?[:/] ?1\b",
    r"\breplique\b",
    r"\breplica\b",
    r"\bcopie\b",
    r"\bfake\b",
    r"\bua\b",
    r"\brep\b",
    r"\binspire (de|par)\b",
    r"\bsans (certificat|authenticite)\b",
]

# Signaux faibles : ne prouvent rien, mais méritent une vérification.
SUSPICIOUS_MILD = [
    r"\bstyle\b",
    r"\bsans boite\b",
    r"\bpas de facture\b",
    r"\bsans facture\b",
    r"\bsans ticket\b",
    r"\bsans preuve d achat\b",
    r"\bpas de retour\b",
]

_NOT_IN_HAND_RE = [re.compile(p) for p in NOT_IN_HAND]
_STRONG_RE = [re.compile(p) for p in COUNTERFEIT_STRONG]
_MILD_RE = [re.compile(p) for p in SUSPICIOUS_MILD]


def _hits(patterns: list[re.Pattern[str]], text: str) -> list[str]:
    return [m.group(0) for p in patterns if (m := p.search(text))]


def find_not_in_hand(text: str) -> list[str]:
    return _hits(_NOT_IN_HAND_RE, normalize(text))


def find_counterfeit_strong(text: str) -> list[str]:
    return _hits(_STRONG_RE, normalize(text))


def find_suspicious_mild(text: str) -> list[str]:
    return _hits(_MILD_RE, normalize(text))
