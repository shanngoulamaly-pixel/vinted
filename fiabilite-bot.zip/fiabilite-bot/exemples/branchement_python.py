"""Exemple : brancher l'évaluation dans votre bot existant écrit en Python (discord.py).

Deux façons de faire, choisissez-en UNE.

A) Même dossier / même programme : importer directement le module (le plus simple).
B) Programmes séparés : appeler l'API HTTP (le bot de fiabilité doit tourner : lancer.bat).

Adaptez la fonction `vers_format_fiabilite` aux noms de champs que VOTRE bot utilise déjà.
"""

import aiohttp

URL_API = "http://127.0.0.1:8787/evaluer"
CLE_API = None  # mettez la clé ici si vous avez créé cle-api.txt


def vers_format_fiabilite(annonce: dict) -> dict:
    """Convertit une annonce telle que votre bot la connaît vers le format attendu.
    Les noms à gauche sont fixes ; ceux à droite sont des EXEMPLES à remplacer par les vôtres.
    Tout est facultatif sauf « titre » et « prix_total » : envoyez ce que vous avez."""
    return {
        "id": annonce.get("id"),
        "titre": annonce.get("title"),
        "description": annonce.get("description", ""),
        "prix": annonce.get("price"),
        "prix_total": annonce.get("total_price"),  # frais de protection inclus
        "url": annonce.get("url"),
        "categorie": annonce.get("category"),  # ex. "playstation", "chaussures"
        "marque": annonce.get("brand"),
        "etat": annonce.get("status"),
        "photos": annonce.get("photos", []),
        "nb_photos": len(annonce.get("photos", [])),
        "vendeur": {
            "pseudo": annonce.get("seller_name"),
            "nb_avis": annonce.get("seller_reviews"),
            "note": annonce.get("seller_rating"),  # sur 5
            "anciennete_jours": annonce.get("seller_account_age_days"),
        },
        "marche": {
            "mediane_ventes": annonce.get("median_sold"),  # prix réellement payés
            "nb_ventes": annonce.get("n_sold", 0),
            "mediane_annonces": annonce.get("median_asking"),  # prix demandés
            "nb_annonces": annonce.get("n_asking", 0),
            "prix_neuf": annonce.get("retail_price"),
            "date_sortie": annonce.get("release_date"),  # "AAAA-MM-JJ"
        },
    }


# --- A) Import direct -------------------------------------------------------
def evaluer_direct(annonce: dict) -> dict:
    from fiabilite import evaluer  # le dossier « fiabilite » doit être à côté de votre bot

    return evaluer(vers_format_fiabilite(annonce))


# --- B) Appel HTTP ------------------------------------------------------------
async def evaluer_http(session: aiohttp.ClientSession, annonce: dict) -> dict | None:
    headers = {"X-Cle-Api": CLE_API} if CLE_API else {}
    try:
        async with session.post(URL_API, json=vers_format_fiabilite(annonce), headers=headers,
                                timeout=aiohttp.ClientTimeout(total=5)) as r:
            if r.status != 200:
                print("Fiabilité : erreur", r.status, await r.text())
                return None
            return await r.json()
    except aiohttp.ClientError as e:
        print("Fiabilité : service injoignable", e)
        return None


# --- Dans votre bot, juste avant de publier une alerte ------------------------
async def avant_de_publier(session, annonce: dict, embed) -> bool:
    """Renvoie False s'il ne faut PAS publier ; sinon ajoute le verdict à votre embed."""
    res = await evaluer_http(session, annonce)  # ou : res = evaluer_direct(annonce)
    if res is None:
        return True  # service indisponible : à vous de choisir (publier quand même, ou non)
    if not res["publier"]:
        print(f"Alerte écartée ({res['libelle']}, {res['score']}/100) : {res['raisons'][0]['texte'] if res['raisons'] else ''}")
        return False
    raisons = "\n".join(f"• {r['texte']}" for r in res["raisons"][:3]) or "Aucun signal de risque."
    embed.add_field(name=f"Fiabilité : {res['libelle']} ({res['score']}/100)", value=raisons[:1024], inline=False)
    return True
