"""Routage d'une alerte vers le bon salon et les bons rôles (à la place de @everyone)."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Optional

from .models import Listing


def slug(value: Optional[str]) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(c for c in value if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "-", value).strip("-")


@dataclass(frozen=True)
class Route:
    channel_id: Optional[int]
    role_ids: tuple[int, ...] = field(default_factory=tuple)


def route(listing: Listing, channels: dict[str, int], roles: dict[str, int]) -> Route:
    """Cherche d'abord « categorie/marque », puis « categorie ».

    Exemple de configuration :
        channels = {"vetements": 111, "vetements/nike": 222}
        roles    = {"vetements": 10, "vetements/nike": 20}
    Une annonce Nike dans « vetements » va dans le salon 222 et mentionne les rôles 20 et 10.
    """
    cat = slug(listing.category)
    brand = slug(listing.brand)
    keys = [f"{cat}/{brand}", cat] if brand else [cat]

    channel_id = next((channels[k] for k in keys if k in channels), None)
    role_ids = tuple(roles[k] for k in keys if k in roles)
    return Route(channel_id=channel_id, role_ids=role_ids)
