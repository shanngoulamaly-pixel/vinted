// Exemple : brancher l'évaluation dans votre bot existant écrit en JavaScript (discord.js, Node 18+).
// Le bot de fiabilité doit tourner sur le même ordinateur (lancer.bat).
// Adaptez `versFormatFiabilite` aux noms de champs que VOTRE bot utilise déjà.

const URL_API = "http://127.0.0.1:8787/evaluer";
const CLE_API = null; // mettez la clé ici si vous avez créé cle-api.txt

function versFormatFiabilite(annonce) {
  // Noms à gauche : fixes. Noms à droite : EXEMPLES à remplacer par les vôtres.
  // Tout est facultatif sauf "titre" et "prix_total" : envoyez ce que vous avez.
  return {
    id: annonce.id,
    titre: annonce.title,
    description: annonce.description ?? "",
    prix: annonce.price,
    prix_total: annonce.totalPrice, // frais de protection inclus
    url: annonce.url,
    categorie: annonce.category, // ex. "playstation", "chaussures"
    marque: annonce.brand,
    etat: annonce.status,
    photos: annonce.photos ?? [],
    nb_photos: (annonce.photos ?? []).length,
    vendeur: {
      pseudo: annonce.sellerName,
      nb_avis: annonce.sellerReviews,
      note: annonce.sellerRating, // sur 5
      anciennete_jours: annonce.sellerAccountAgeDays,
    },
    marche: {
      mediane_ventes: annonce.medianSold, // prix réellement payés
      nb_ventes: annonce.nSold ?? 0,
      mediane_annonces: annonce.medianAsking, // prix demandés
      nb_annonces: annonce.nAsking ?? 0,
      prix_neuf: annonce.retailPrice,
      date_sortie: annonce.releaseDate, // "AAAA-MM-JJ"
    },
  };
}

async function evaluerFiabilite(annonce) {
  try {
    const reponse = await fetch(URL_API, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(CLE_API ? { "X-Cle-Api": CLE_API } : {}) },
      body: JSON.stringify(versFormatFiabilite(annonce)),
      signal: AbortSignal.timeout(5000),
    });
    if (!reponse.ok) {
      console.error("Fiabilité : erreur", reponse.status, await reponse.text());
      return null;
    }
    return await reponse.json();
  } catch (e) {
    console.error("Fiabilité : service injoignable", e.message);
    return null;
  }
}

// Dans votre bot, juste avant de publier une alerte :
// renvoie false s'il ne faut PAS publier ; sinon ajoute le verdict à votre embed (EmbedBuilder).
async function avantDePublier(annonce, embed) {
  const res = await evaluerFiabilite(annonce);
  if (res === null) return true; // service indisponible : à vous de choisir
  if (!res.publier) {
    console.log(`Alerte écartée (${res.libelle}, ${res.score}/100) : ${res.raisons[0]?.texte ?? ""}`);
    return false;
  }
  const raisons = res.raisons.slice(0, 3).map((r) => `• ${r.texte}`).join("\n") || "Aucun signal de risque.";
  embed.addFields({ name: `Fiabilité : ${res.libelle} (${res.score}/100)`, value: raisons.slice(0, 1024) });
  return true;
}

module.exports = { evaluerFiabilite, avantDePublier };
