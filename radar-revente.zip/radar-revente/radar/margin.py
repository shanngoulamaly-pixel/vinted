"""Calcul de marge honnête : frais de revente et cotisations inclus."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class MarginResult:
    buy_total: float  # ce que tu paies, frais inclus
    resale_price: float  # prix de revente visé
    resale_costs: float  # frais de revente estimés (port, emballage...)
    gross: float  # marge avant cotisations
    cotisations: float  # cotisations sociales sur le CA encaissé
    net: float  # marge après cotisations

    @property
    def gross_pct(self) -> float:
        return self.gross / self.resale_price * 100 if self.resale_price else 0.0


def compute_margin(
    buy_total: float,
    resale_price: float,
    resale_costs: float = 0.0,
    cotisation_rate: float = 0.123,
    micro_entreprise: bool = True,
) -> MarginResult:
    """Marge d'une revente.

    Les cotisations d'une micro-entreprise portent sur le chiffre d'affaires encaissé
    (le prix de revente), pas sur le bénéfice : les achats ne les réduisent pas.
    Le taux par défaut (12,3 %) est un ordre de grandeur pour la vente de marchandises :
    à confirmer sur urssaf.fr.
    """
    gross = resale_price - buy_total - resale_costs
    cotisations = resale_price * cotisation_rate if micro_entreprise else 0.0
    return MarginResult(
        buy_total=round(buy_total, 2),
        resale_price=round(resale_price, 2),
        resale_costs=round(resale_costs, 2),
        gross=round(gross, 2),
        cotisations=round(cotisations, 2),
        net=round(gross - cotisations, 2),
    )
