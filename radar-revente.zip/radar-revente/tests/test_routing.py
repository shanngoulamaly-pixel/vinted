from radar.models import Listing
from radar.routing import route, slug

CHANNELS = {"vetements": 1, "vetements/nike": 2, "playstation": 3}
ROLES = {"vetements": 10, "vetements/nike": 20}


def make(category, brand=None):
    return Listing(
        id="x", title="t", description="d", price=10, buyer_total=11, url="https://example.invalid", category=category, brand=brand
    )


def test_slug():
    assert slug("Beauté & Soins") == "beaute-soins"
    assert slug(None) == ""


def test_brand_channel_and_roles_are_used_first():
    r = route(make("vetements", "Nike"), CHANNELS, ROLES)
    assert r.channel_id == 2
    assert r.role_ids == (20, 10)


def test_falls_back_to_category():
    r = route(make("vetements", "Zara"), CHANNELS, ROLES)
    assert r.channel_id == 1
    assert r.role_ids == (10,)


def test_unknown_category_has_no_channel():
    r = route(make("lego"), CHANNELS, ROLES)
    assert r.channel_id is None and r.role_ids == ()
