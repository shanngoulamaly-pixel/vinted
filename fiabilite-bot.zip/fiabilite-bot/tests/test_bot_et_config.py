import asyncio
import json
from datetime import date

from fiabilite import evaluer
from fiabilite.bot import BotFiabilite, VueVerification, barre, carte
from fiabilite.config import charger_config, token_discord

RES = evaluer({
    "titre": "Baskets style 1:1", "description": "Qualité UA. Paiement PayPal. WhatsApp 06 12 34 56 78. " * 3,
    "prix_total": 48.2, "marche": {"mediane_ventes": 140, "nb_ventes": 18},
}, aujourdhui=date(2026, 11, 10))


def test_carte_respecte_les_limites_discord():
    e = carte(RES, "Baskets style 1:1" * 30, url="pas une url", photo=None)
    assert len(e.title) <= 256 and e.url is None
    assert all(len(f.value) <= 1024 for f in e.fields)
    assert "À éviter" in e.description and "garantie" in e.footer.text


def test_vue_boutons():
    async def run():
        v = VueVerification(RES, "https://www.vinted.fr/items/1", "https://cdn.example/p.jpg")
        labels = [getattr(i, "label", "") for i in v.children]
        assert {"Ouvrir l'annonce", "Photo : Google Lens", "Checklist", "Message au vendeur"} <= set(labels)
        assert not any("auto" in l.lower() or "achet" in l.lower() for l in labels)
        v2 = VueVerification(RES, None, None)
        assert {getattr(i, "label", "") for i in v2.children} == {"Checklist", "Message au vendeur"}

    asyncio.run(run())


def test_commande_verifier_enregistree():
    async def run():
        bot = BotFiabilite()
        noms = [c.name for c in bot.tree.get_commands()]
        assert noms == ["verifier"]
        params = {p.name for p in bot.tree.get_command("verifier").parameters}
        assert {"categorie", "prix_total", "revente", "photo", "prive"} <= params
        await bot.close()

    asyncio.run(run())


def test_barre():
    assert barre(0) == "░" * 10 and barre(100) == "█" * 10


def test_config_et_token(tmp_path, monkeypatch):
    (tmp_path / "c.json").write_text(json.dumps({"port": 9000, "seuil_publication": 70}), encoding="utf-8")
    cfg = charger_config(tmp_path / "c.json")
    assert cfg.port == 9000 and cfg.hote == "127.0.0.1" and cfg.options.seuil_publication == 70
    assert charger_config(tmp_path / "absent.json").port == 8787

    monkeypatch.delenv("DISCORD_TOKEN", raising=False)
    monkeypatch.chdir(tmp_path)
    assert token_discord(home=tmp_path) is None
    (tmp_path / "Desktop").mkdir()
    (tmp_path / "Desktop" / "token.txt.txt").write_text("﻿abc\n", encoding="utf-8")
    assert token_discord(home=tmp_path) == "abc"
