"""Score de fiabilité d'une annonce (0 à 100) et raisons détaillées.

On part de 100 et on retire des points pour chaque signal de risque.
Les signaux BLOQUANTS (objet pas en main, paiement hors Vinted, photo volée...) mettent le score à 0.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional, Protocol

from .keywords import (
    find_counterfeit_strong,
    find_not_in_hand,
    find_off_platform_contact,
    find_off_platform_payment,
    find_stock_photos,
    find_suspicious_mild,
    find_urgency,
)
from .models import Annonce, Marche


@dataclass(frozen=True)
class Raison:
    code: str
    points: int  # négatif = pénalité
    texte: str
    bloquante: bool = False


@dataclass(frozen=True)
class Score:
    score: int
    bloquee: bool
    raisons: tuple[Raison, ...]

    @property
    def verdict(self) -> str:
        if self.bloquee:
            return "a_eviter"
        if self.score >= 75:
            return "fiable"
        if self.score >= 50:
            return "a_verifier"
        return "risque_eleve"

    @property
    def libelle(self) -> str:
        return {
            "a_eviter": "À éviter",
            "fiable": "Fiable",
            "a_verifier": "À vérifier",
            "risque_eleve": "Risque élevé",
        }[self.verdict]


@dataclass(frozen=True)
class ResultatImage:
    reutilisee: Optional[bool]  # True : photo trouvée ailleurs ; None : non vérifié


class VerificateurImage(Protocol):
    """À brancher sur un service de recherche d'image inversée de votre choix."""

    def verifier(self, photos: tuple[str, ...]) -> ResultatImage: ...


@dataclass(frozen=True)
class Reglages:
    ecart_suspect: float = 0.40  # prix plus de 40 % sous les ventes
    ecart_extreme: float = 0.60
    valeur_min_ecart: float = 50.0  # sous cette valeur, un gros écart est surtout un vendeur qui ignore le prix
    ventes_min_ok: int = 10
    ventes_min_faible: int = 5
    ratio_speculatif: float = 2.0  # revente observée > 2x le prix neuf


def ecart_prix(annonce: Annonce, marche: Marche) -> Optional[float]:
    """0,43 = l'acheteur paie 43 % de moins que la médiane des ventes."""
    if not marche.mediane_ventes or marche.mediane_ventes <= 0 or annonce.prix_total <= 0:
        return None
    return 1 - annonce.prix_total / marche.mediane_ventes


def evaluer_score(
    annonce: Annonce,
    marche: Marche,
    aujourdhui: Optional[date] = None,
    verificateur_image: Optional[VerificateurImage] = None,
    reglages: Reglages = Reglages(),
) -> Score:
    aujourdhui = aujourdhui or date.today()
    r: list[Raison] = []
    texte = f"{annonce.titre}\n{annonce.description}"

    # --- Signaux bloquants ---
    if marche.date_sortie and aujourdhui < marche.date_sortie:
        r.append(Raison("pas_sorti", -100, f"Produit pas encore sorti (sortie le {marche.date_sortie:%d/%m/%Y}).", True))
    if hits := find_not_in_hand(texte):
        r.append(Raison("pas_en_main", -100, f"Le vendeur n'a pas l'objet en main (« {hits[0]} »).", True))
    if hits := find_off_platform_payment(texte):
        r.append(Raison(
            "paiement_hors_vinted", -100,
            f"Paiement hors Vinted évoqué (« {hits[0]} ») : arnaque classique, aucune protection acheteur.", True,
        ))
    if verificateur_image is not None and annonce.photos:
        if verificateur_image.verifier(annonce.photos).reutilisee:
            r.append(Raison("photo_reutilisee", -100, "Photo déjà présente ailleurs sur internet.", True))

    # --- Texte de l'annonce ---
    if hits := find_off_platform_contact(texte):
        r.append(Raison("contact_hors_vinted", -30, f"Invite à continuer hors de Vinted (« {hits[0]} »)."))
    if hits := find_counterfeit_strong(texte):
        r.append(Raison("contrefacon", -50, f"Mot-clé de contrefaçon : « {hits[0]} »."))
    if hits := find_stock_photos(texte):
        r.append(Raison("photos_internet", -15, f"Photos qui ne sont peut-être pas celles de l'objet (« {hits[0]} »)."))
    if hits := find_suspicious_mild(texte):
        r.append(Raison("mot_a_verifier", -10, f"Mot-clé à vérifier : « {hits[0]} »."))
    if hits := find_urgency(texte):
        r.append(Raison("urgence", -5, f"Pression pour acheter vite (« {hits[0]} »)."))
    if len(annonce.description.strip()) < 20:
        r.append(Raison("description_courte", -5, "Description absente ou très courte."))

    # --- Prix ---
    ecart = ecart_prix(annonce, marche)
    if ecart is None:
        r.append(Raison("pas_de_reference", -15, "Pas de prix de référence : impossible de juger si le prix est normal."))
    elif marche.mediane_ventes >= reglages.valeur_min_ecart:
        pct = round(ecart * 100)
        if ecart > reglages.ecart_extreme:
            r.append(Raison("ecart_extreme", -35, f"Prix {pct} % sous les ventes : très suspect."))
        elif ecart > reglages.ecart_suspect:
            r.append(Raison("ecart_suspect", -25, f"Prix {pct} % sous les ventes : possible arnaque ou contrefaçon."))
        elif ecart > 0.25:
            r.append(Raison("ecart_notable", -5, f"Prix {pct} % sous les ventes."))

    if marche.mediane_ventes:
        if marche.nb_ventes == 0:
            r.append(Raison("reference_estimee", -5, "Prix de référence estimé, sans ventes observées."))
        elif marche.nb_ventes < reglages.ventes_min_faible:
            r.append(Raison("peu_de_ventes", -15, f"Référence basée sur seulement {marche.nb_ventes} ventes."))
        elif marche.nb_ventes < reglages.ventes_min_ok:
            r.append(Raison("ventes_limitees", -5, f"Référence basée sur {marche.nb_ventes} ventes."))

    if marche.prix_neuf and marche.mediane_ventes and marche.mediane_ventes > reglages.ratio_speculatif * marche.prix_neuf:
        r.append(Raison(
            "speculatif", -15,
            f"Revente observée ({marche.mediane_ventes:.0f} €) plus de {reglages.ratio_speculatif:.0f}x "
            f"le prix neuf ({marche.prix_neuf:.0f} €) : référence spéculative.",
        ))

    # --- Vendeur ---
    v = annonce.vendeur
    compte_recent = False
    if v is None:
        r.append(Raison("vendeur_inconnu", -10, "Profil du vendeur non fourni : vérifie ses avis avant d'acheter."))
    else:
        if v.nb_avis == 0:
            r.append(Raison("vendeur_sans_avis", -20, "Vendeur sans aucun avis."))
        elif v.nb_avis is not None and v.nb_avis < 5:
            r.append(Raison("vendeur_peu_avis", -10, f"Vendeur avec seulement {v.nb_avis} avis."))
        elif v.note is not None and v.note < 4.5:
            r.append(Raison("vendeur_note_basse", -10, f"Note du vendeur : {v.note:.1f}/5."))
        if v.anciennete_jours is not None and v.anciennete_jours < 30:
            compte_recent = True
            r.append(Raison("compte_recent", -15, "Compte créé il y a moins de 30 jours."))
        if v.nb_articles_meme_marque is not None and v.nb_articles_meme_marque > 10:
            r.append(Raison(
                "stock_meme_marque", -15,
                f"Le vendeur propose {v.nb_articles_meme_marque} articles de la même marque.",
            ))

    if compte_recent and ecart is not None and ecart > reglages.ecart_suspect:
        r.append(Raison("combinaison_arnaque", -10, "Compte récent et prix très bas : combinaison typique d'arnaque."))

    # --- Photos ---
    nb = annonce.nombre_photos
    if nb is not None and nb <= 1:
        r.append(Raison("peu_de_photos", -10, "Une seule photo (ou aucune)."))

    bloquee = any(x.bloquante for x in r)
    score = 0 if bloquee else max(0, min(100, 100 + sum(x.points for x in r)))
    ordonnees = tuple(sorted(r, key=lambda x: (not x.bloquante, x.points)))
    return Score(score=score, bloquee=bloquee, raisons=ordonnees)
