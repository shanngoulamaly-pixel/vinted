"""Point d'entrée unique : evaluer(dict) -> dict.

Utilisable de trois façons :
  - importé directement dans un bot Python : `from fiabilite import evaluer`
  - via l'API HTTP locale (fiabilite/serveur.py) depuis n'importe quel langage
  - via la commande Discord /verifier (fiabilite/bot.py)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any, Optional

from .checklists import checklist, message_vendeur, slug
from .margin import compute_margin
from .models import Annonce, Marche, Vendeur
from .scoring import Reglages, VerificateurImage, ecart_prix, evaluer_score


class ErreurEntree(ValueError):
    """Données d'annonce invalides (message lisible, renvoyé tel quel par l'API)."""


@dataclass(frozen=True)
class Options:
    seuil_publication: int = 60  # score minimal pour conseiller de publier l'alerte
    taux_cotisations: float = 0.123  # micro-entreprise, vente de marchandises (à confirmer sur urssaf.fr)
    frais_revente_defaut: float = 5.0


def _nombre(d: dict, cle: str, entier: bool = False, requis: bool = False) -> Optional[float]:
    v = d.get(cle)
    if v is None or v == "":
        if requis:
            raise ErreurEntree(f"Champ obligatoire manquant : « {cle} ».")
        return None
    try:
        n = float(str(v).replace(",", ".").replace("€", "").strip())
    except ValueError:
        raise ErreurEntree(f"« {cle} » doit être un nombre (reçu : {v!r}).") from None
    if n < 0:
        raise ErreurEntree(f"« {cle} » ne peut pas être négatif.")
    return int(n) if entier else n


def _texte(d: dict, cle: str) -> Optional[str]:
    v = d.get(cle)
    return str(v).strip() if v not in (None, "") else None


def lire_annonce(data: dict[str, Any]) -> tuple[Annonce, Marche]:
    if not isinstance(data, dict):
        raise ErreurEntree("Le corps doit être un objet JSON décrivant une annonce.")
    titre = _texte(data, "titre")
    if not titre:
        raise ErreurEntree("Champ obligatoire manquant : « titre ».")
    prix = _nombre(data, "prix")
    prix_total = _nombre(data, "prix_total")
    if prix_total is None:
        if prix is None:
            raise ErreurEntree("Il faut au moins « prix_total » (frais inclus) ou « prix ».")
        prix_total = prix

    v = data.get("vendeur")
    vendeur = None
    if isinstance(v, dict) and any(v.get(k) not in (None, "") for k in v):
        vendeur = Vendeur(
            pseudo=_texte(v, "pseudo"),
            nb_avis=_nombre(v, "nb_avis", entier=True),
            note=_nombre(v, "note"),
            anciennete_jours=_nombre(v, "anciennete_jours", entier=True),
            nb_articles_meme_marque=_nombre(v, "nb_articles_meme_marque", entier=True),
        )
        if vendeur.note is not None and vendeur.note > 5:
            raise ErreurEntree("« vendeur.note » doit être sur 5.")

    photos = data.get("photos") or []
    if isinstance(photos, str):
        photos = [photos]
    annonce = Annonce(
        titre=titre,
        description=_texte(data, "description") or "",
        prix=prix,
        prix_total=prix_total,
        id=_texte(data, "id"),
        url=_texte(data, "url"),
        categorie=_texte(data, "categorie"),
        marque=_texte(data, "marque"),
        etat=_texte(data, "etat"),
        photos=tuple(str(p) for p in photos if p),
        nb_photos=_nombre(data, "nb_photos", entier=True),
        vendeur=vendeur,
    )

    m = data.get("marche") or {}
    if not isinstance(m, dict):
        raise ErreurEntree("« marche » doit être un objet.")
    date_sortie = None
    if m.get("date_sortie"):
        try:
            date_sortie = date.fromisoformat(str(m["date_sortie"])[:10])
        except ValueError:
            raise ErreurEntree("« marche.date_sortie » doit être au format AAAA-MM-JJ.") from None
    marche = Marche(
        mediane_ventes=_nombre(m, "mediane_ventes"),
        nb_ventes=_nombre(m, "nb_ventes", entier=True) or 0,
        mediane_annonces=_nombre(m, "mediane_annonces"),
        nb_annonces=_nombre(m, "nb_annonces", entier=True) or 0,
        prix_neuf=_nombre(m, "prix_neuf"),
        date_sortie=date_sortie,
    )
    return annonce, marche


def infos_manquantes(annonce: Annonce, marche: Marche) -> list[str]:
    manque = []
    if not annonce.description:
        manque.append("description")
    if annonce.vendeur is None:
        manque.append("profil du vendeur (avis, note, ancienneté)")
    if not marche.mediane_ventes:
        manque.append("prix de référence (médiane des ventes)")
    elif marche.nb_ventes == 0:
        manque.append("nombre de ventes derrière le prix de référence")
    if annonce.nombre_photos is None:
        manque.append("nombre de photos")
    if not annonce.categorie:
        manque.append("catégorie (pour la checklist)")
    return manque


def evaluer(
    data: dict[str, Any],
    options: Options = Options(),
    aujourdhui: Optional[date] = None,
    verificateur_image: Optional[VerificateurImage] = None,
) -> dict[str, Any]:
    """Évalue une annonce décrite en JSON (voir README) et renvoie le verdict en JSON."""
    annonce, marche = lire_annonce(data)
    s = evaluer_score(annonce, marche, aujourdhui=aujourdhui, verificateur_image=verificateur_image)

    marge = None
    if marche.mediane_ventes:
        revente = data.get("revente") or {}
        frais = _nombre(revente, "frais") if isinstance(revente, dict) else None
        taux = _nombre(revente, "taux_cotisations") if isinstance(revente, dict) else None
        m = compute_margin(
            buy_total=annonce.prix_total,
            resale_price=marche.mediane_ventes,
            resale_costs=options.frais_revente_defaut if frais is None else frais,
            cotisation_rate=options.taux_cotisations if taux is None else taux,
        )
        marge = {
            "prix_revente": m.resale_price,
            "frais_revente": m.resale_costs,
            "brute": m.gross,
            "cotisations": m.cotisations,
            "nette": m.net,
        }

    ecart = ecart_prix(annonce, marche)
    return {
        "id": annonce.id,
        "score": s.score,
        "verdict": s.verdict,
        "libelle": s.libelle,
        "bloquee": s.bloquee,
        "publier": (not s.bloquee) and s.score >= options.seuil_publication,
        "raisons": [
            {"code": r.code, "points": r.points, "texte": r.texte, "bloquante": r.bloquante} for r in s.raisons
        ],
        "ecart_prix_pct": round(ecart * 100) if ecart is not None else None,
        "marge": marge,
        "infos_manquantes": infos_manquantes(annonce, marche),
        "categorie": slug(annonce.categorie) or None,
        "checklist": checklist(annonce.categorie),
        "message_vendeur": message_vendeur(annonce),
        "avertissement": "Analyse automatique : estimation, pas une garantie. Vérifie toujours l'annonce avant d'acheter.",
    }
