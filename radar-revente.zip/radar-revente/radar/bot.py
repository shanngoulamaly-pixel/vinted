"""Bot Discord : publie les alertes qui passent le filtre, dans le bon salon, avec les bons rôles."""

from __future__ import annotations

import logging
from datetime import date
from typing import Optional

import discord
from discord import app_commands
from discord.ext import tasks

from .config import BotConfig
from .pipeline import Decision, SeenStore, evaluate
from .scoring import ImageChecker
from .sources import ListingSource, load_candidates
from .ui import AlertView, build_embed

log = logging.getLogger("radar")

# Seuls les rôles de la configuration sont mentionnés : jamais @everyone.
ALLOWED = discord.AllowedMentions(everyone=False, users=False, roles=True)


class RadarBot(discord.Client):
    def __init__(
        self,
        cfg: BotConfig,
        source: ListingSource,
        image_checker: Optional[ImageChecker] = None,
        sample_path: Optional[str] = None,
    ):
        super().__init__(intents=discord.Intents.default())
        self.cfg, self.source, self.image_checker = cfg, source, image_checker
        self.seen = SeenStore(cfg.seen_path)
        self.tree = app_commands.CommandTree(self)
        self._poller = tasks.loop(seconds=cfg.poll_seconds)(self._poll)
        self._poller.before_loop(self._before_poll)

        @self.tree.command(name="demo", description="Affiche des alertes d'exemple (administrateurs)")
        @app_commands.default_permissions(administrator=True)
        async def demo(interaction: discord.Interaction):
            await interaction.response.defer(ephemeral=True)
            if not sample_path or interaction.channel is None:
                await interaction.followup.send("Aucune donnée d'exemple configurée.", ephemeral=True)
                return
            skipped = []
            for cand in load_candidates(sample_path):
                d = evaluate(cand, self.cfg, self.image_checker, today=date.today())
                if d.post:
                    await interaction.channel.send(embed=build_embed(d), view=AlertView(d, self.cfg))
                else:
                    skipped.append(f"Bloquée : **{cand.listing.title}** → {d.skip_reason}")
            await interaction.followup.send("\n".join(skipped) or "Terminé.", ephemeral=True)

    async def setup_hook(self) -> None:
        if self.cfg.guild_id:
            guild = discord.Object(id=self.cfg.guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()
        self._poller.start()

    async def _before_poll(self) -> None:
        await self.wait_until_ready()

    async def post(self, decision: Decision) -> None:
        channel_id = decision.route.channel_id
        if channel_id is None:
            log.warning("Pas de salon configuré pour %s", decision.candidate.listing.category)
            return
        channel = self.get_channel(channel_id) or await self.fetch_channel(channel_id)
        mentions = " ".join(f"<@&{rid}>" for rid in decision.route.role_ids)
        await channel.send(
            content=mentions or None,
            embed=build_embed(decision),
            view=AlertView(decision, self.cfg),
            allowed_mentions=ALLOWED,
        )

    async def _poll(self) -> None:
        for cand in await self.source.fetch_new():
            lid = cand.listing.id
            if lid in self.seen:
                continue
            self.seen.add(lid)
            try:
                decision = evaluate(cand, self.cfg, self.image_checker)
                if decision.post:
                    await self.post(decision)
                else:
                    log.info("Annonce %s écartée : %s", lid, decision.skip_reason)
            except Exception:
                log.exception("Erreur sur l'annonce %s", lid)
