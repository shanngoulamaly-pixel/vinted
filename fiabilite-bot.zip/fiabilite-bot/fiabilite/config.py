"""Configuration (config.json) et secrets (token Discord, clé API).

Les secrets ne vont jamais dans config.json : variables d'environnement ou fichiers texte.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .api import Options


@dataclass(frozen=True)
class Config:
    hote: str = "127.0.0.1"  # 127.0.0.1 = accessible seulement depuis cet ordinateur
    port: int = 8787
    options: Options = Options()


def charger_config(chemin: str | Path) -> Config:
    p = Path(chemin)
    raw = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    return Config(
        hote=raw.get("hote", "127.0.0.1"),
        port=int(raw.get("port", 8787)),
        options=Options(
            seuil_publication=int(raw.get("seuil_publication", 60)),
            taux_cotisations=float(raw.get("taux_cotisations", 0.123)),
            frais_revente_defaut=float(raw.get("frais_revente_defaut", 5.0)),
        ),
    )


def _dossiers(home: Path) -> list[Path]:
    return [Path.cwd(), home / "Desktop", home / "Bureau", home / "OneDrive" / "Desktop", home / "OneDrive" / "Bureau"]


def lire_secret(variable: str, fichier: str, home: Optional[Path] = None) -> Optional[str]:
    """Cherche la variable d'environnement, puis le fichier (dossier du bot ou bureau).
    Gère « token.txt.txt » (extension masquée par Windows)."""
    valeur = os.environ.get(variable, "").strip()
    if valeur:
        return valeur
    for dossier in _dossiers(home or Path.home()):
        for nom in (fichier, fichier + ".txt"):
            chemin = dossier / nom
            if chemin.is_file():
                valeur = chemin.read_text(encoding="utf-8-sig").strip()
                if valeur:
                    return valeur
    return None


def token_discord(home: Optional[Path] = None) -> Optional[str]:
    return lire_secret("DISCORD_TOKEN", "token.txt", home)


def cle_api(home: Optional[Path] = None) -> Optional[str]:
    return lire_secret("FIABILITE_CLE", "cle-api.txt", home)
