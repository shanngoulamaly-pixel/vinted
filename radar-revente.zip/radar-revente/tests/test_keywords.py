import pytest

from radar.keywords import (
    find_counterfeit_strong,
    find_not_in_hand,
    find_suspicious_mild,
    normalize,
)


def test_normalize_strips_accents_and_case():
    assert normalize("  Après SA Réception ") == "apres sa reception"
    assert normalize("pré-commande") == "pre commande"


@pytest.mark.parametrize(
    "text",
    [
        "Disponible après sa réception le 19 Novembre.",  # le cas réel de la manette
        "Vendu en précommande, livraison le mois prochain",
        "Pré-commande, je l'expédie dès ma réception",
        "Article sur commande",
        "Je ne l'ai pas encore reçu",
        "Je le reçois la semaine prochaine",
        "Pas encore en ma possession",
    ],
)
def test_detects_items_not_in_hand(text):
    assert find_not_in_hand(text), text


@pytest.mark.parametrize(
    "text",
    [
        "J'expédie dès réception du paiement",
        "Envoi après réception du paiement sous 48h",
        "Livraison prévue sous 3 jours",
        "Disponible immédiatement, envoi soigné",
        "Reçu en cadeau, jamais utilisé",
    ],
)
def test_no_false_positive_on_normal_selling_phrases(text):
    assert not find_not_in_hand(text), text


@pytest.mark.parametrize(
    "text", ["Baskets style 1:1", "qualité UA", "réplique parfaite", "inspiré de la marque", "rep de très bonne qualité"]
)
def test_detects_counterfeit_keywords(text):
    assert find_counterfeit_strong(text), text


def test_counterfeit_keywords_do_not_match_inside_words():
    assert not find_counterfeit_strong("Je dois repasser la veste, tissu uaa")
    assert not find_counterfeit_strong("Veste en jean, taille M")


def test_mild_keywords():
    assert find_suspicious_mild("Livré sans boîte et sans facture")
    assert not find_suspicious_mild("Boîte d'origine et facture jointes")
