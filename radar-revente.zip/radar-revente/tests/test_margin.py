from radar.margin import compute_margin


def test_margin_matches_the_manual_calculation():
    # Exemple réel de la discussion : achat 189,70 €, revente 330 €, 11 € de frais.
    m = compute_margin(buy_total=189.70, resale_price=330.0, resale_costs=11.0, cotisation_rate=0.123)
    assert m.gross == 129.30
    assert m.cotisations == 40.59  # 12,3 % du prix de revente, pas du bénéfice
    assert m.net == 88.71


def test_cotisations_ignore_the_purchase_price():
    cheap = compute_margin(100, 200, 0)
    dear = compute_margin(190, 200, 0)
    assert cheap.cotisations == dear.cotisations  # même CA, mêmes cotisations


def test_thin_margin_can_be_negative_after_cotisations():
    m = compute_margin(buy_total=2800, resale_price=3000, resale_costs=0)
    assert m.gross == 200
    assert m.net < 0  # 200 € de marge brute, 369 € de cotisations


def test_no_cotisations_outside_micro_entreprise():
    m = compute_margin(50, 100, 5, micro_entreprise=False)
    assert m.cotisations == 0 and m.net == m.gross == 45
