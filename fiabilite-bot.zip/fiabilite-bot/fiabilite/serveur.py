"""API HTTP locale : votre bot existant envoie l'annonce, reçoit le verdict.

    POST /evaluer        une annonce (JSON)          -> verdict (JSON)
    POST /evaluer-lot    une liste d'annonces (max 100) -> liste de verdicts
    GET  /sante          vérifie que le service tourne

Si une clé est configurée, chaque appel doit envoyer l'en-tête « X-Cle-Api ».
"""

from __future__ import annotations

import hmac
import json
import logging
from typing import Optional

from aiohttp import web

from .api import ErreurEntree, Options, evaluer

log = logging.getLogger("fiabilite.serveur")
MAX_LOT = 100


def _erreur(statut: int, message: str) -> web.Response:
    return web.json_response({"erreur": message}, status=statut)


def creer_app(options: Options = Options(), cle_api: Optional[str] = None) -> web.Application:
    @web.middleware
    async def verifier_cle(request: web.Request, handler):
        if cle_api and request.path != "/sante":
            recue = request.headers.get("X-Cle-Api", "")
            if not hmac.compare_digest(recue, cle_api):
                return _erreur(401, "Clé API absente ou invalide (en-tête X-Cle-Api).")
        return await handler(request)

    async def lire_json(request: web.Request):
        try:
            return await request.json(loads=json.loads)
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise web.HTTPBadRequest(
                text=json.dumps({"erreur": "Corps JSON invalide."}), content_type="application/json"
            )

    async def sante(_: web.Request) -> web.Response:
        return web.json_response({"ok": True})

    async def evaluer_une(request: web.Request) -> web.Response:
        data = await lire_json(request)
        try:
            return web.json_response(evaluer(data, options))
        except ErreurEntree as e:
            return _erreur(400, str(e))

    async def evaluer_lot(request: web.Request) -> web.Response:
        data = await lire_json(request)
        if not isinstance(data, list):
            return _erreur(400, "Le corps doit être une liste d'annonces.")
        if len(data) > MAX_LOT:
            return _erreur(400, f"Maximum {MAX_LOT} annonces par appel.")
        resultats = []
        for i, item in enumerate(data):
            try:
                resultats.append(evaluer(item, options))
            except ErreurEntree as e:
                resultats.append({"erreur": str(e), "index": i})
        return web.json_response(resultats)

    app = web.Application(middlewares=[verifier_cle], client_max_size=1024 * 1024)
    app.add_routes([
        web.get("/sante", sante),
        web.post("/evaluer", evaluer_une),
        web.post("/evaluer-lot", evaluer_lot),
    ])
    return app


async def demarrer(app: web.Application, hote: str, port: int) -> web.AppRunner:
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, hote, port).start()
    log.info("API de fiabilité prête sur http://%s:%s", hote, port)
    return runner
