import pytest

from fiabilite.keywords import (
    find_counterfeit_strong,
    find_not_in_hand,
    find_off_platform_contact,
    find_off_platform_payment,
    find_stock_photos,
    find_urgency,
)


@pytest.mark.parametrize("texte", [
    "Disponible après sa réception le 19 Novembre.",
    "Vendu en précommande",
    "Je ne l'ai pas encore reçu",
    "Je le reçois la semaine prochaine",
])
def test_objet_pas_en_main(texte):
    assert find_not_in_hand(texte)


@pytest.mark.parametrize("texte", [
    "J'expédie dès réception du paiement",
    "Envoi après réception du paiement sous 48h",
    "Livraison prévue sous 3 jours",
])
def test_pas_de_faux_positif_sur_les_phrases_d_envoi(texte):
    assert not find_not_in_hand(texte)


@pytest.mark.parametrize("texte", [
    "Paiement PayPal possible", "par virement uniquement", "Lydia ok", "en dehors de Vinted c'est moins cher",
    "Paiement hors Vinted", "je préfère sans passer par Vinted",
])
def test_paiement_hors_vinted(texte):
    assert find_off_platform_payment(texte)


@pytest.mark.parametrize("texte", [
    "Contacte-moi sur WhatsApp", "mon num 06 12 34 56 78", "+33 7 12 34 56 78", "écris-moi à vendeur.top@gmail.com",
    "plus de photos sur https://monsite.example/catalogue", "Ajoute-moi sur Snap",
])
def test_contact_hors_vinted(texte):
    assert find_off_platform_contact(texte)


def test_un_lien_vinted_n_est_pas_un_contact_externe():
    assert not find_off_platform_contact("Voir aussi https://www.vinted.fr/items/123 dans mon dressing")
    assert not find_off_platform_contact("Taille 42, prix ferme 45 €, envoi Mondial Relay")


def test_contrefacon_et_mots_entiers():
    assert find_counterfeit_strong("qualité UA, style 1:1")
    assert not find_counterfeit_strong("Je dois repasser la veste")


def test_urgence_et_photos_internet():
    assert find_urgency("Urgent, premier arrivé premier servi")
    assert find_stock_photos("Photos internet, photo non contractuelle")
    assert not find_stock_photos("Photos prises par moi aujourd'hui")
