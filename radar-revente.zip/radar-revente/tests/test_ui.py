import asyncio
from datetime import date

import discord

from radar.checklists import checklist_for, seller_message
from radar.config import BotConfig
from radar.pipeline import evaluate
from radar.sources import load_candidates
from radar.ui import AlertView, build_embed, score_bar

CFG = BotConfig(resale_costs={"playstation": 11.0})


def decision(index=0):
    cand = load_candidates("data/sample_candidates.json")[index]
    return evaluate(cand, CFG, today=date(2026, 11, 10))


def test_score_bar():
    assert score_bar(0) == "░" * 10
    assert score_bar(100) == "█" * 10
    assert score_bar(55).count("█") in (5, 6)


def test_embed_shows_prudent_gap_and_net_margin():
    e = build_embed(decision(0))
    text = " ".join(f"{f.name} {f.value}" for f in e.fields)
    assert "après cotisations" in text
    assert "sous les ventes" in text
    assert "prix demandés, pas payés" in text
    assert "garantie de gain" in e.footer.text
    assert all(len(f.value) <= 1024 for f in e.fields)


def test_embed_shows_official_price_when_known():
    e = build_embed(decision(1))  # la manette bloquée a un prix officiel
    assert "Prix officiel" in " ".join(f.value for f in e.fields)


def test_view_has_a_link_button_and_no_auto_buy():
    async def run():
        view = AlertView(decision(0), CFG)
        labels = [getattr(i, "label", "") for i in view.children]
        links = [i for i in view.children if getattr(i, "url", None)]
        assert "Ouvrir l'annonce" in labels
        assert links and all(i.style == discord.ButtonStyle.link for i in links)
        assert not any("auto" in (l or "").lower() for l in labels)
        assert len(view.children) <= 25

    asyncio.run(run())


def test_checklist_is_adapted_and_never_mentions_console_for_clothes():
    clothes = " ".join(checklist_for("vetements")).lower()
    assert "console" not in clothes and "étiquette" in clothes
    assert "protection acheteur" in " ".join(checklist_for("categorie-inconnue")).lower()


def test_seller_message_contains_dated_photo_request_and_offer():
    cand = load_candidates("data/sample_candidates.json")[0]
    msg = seller_message(cand.listing)
    assert "papier daté" in msg and "53 €" in msg  # 62 € * 0,85 arrondi
